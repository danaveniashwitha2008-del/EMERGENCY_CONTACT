"""Core business logic engine for Emergency Contact Organizer."""

from __future__ import annotations

from collections import Counter, defaultdict
import csv
from datetime import date, datetime
from pathlib import Path
import statistics
from typing import Any

from .models import (
    CATEGORY_SLA_MAX_MINS,
    VALID_AVAILABILITIES,
    VALID_CATEGORIES,
    VALID_STATUSES,
    EmergencyContact,
    ImportResult,
    RowError,
    SummaryMetrics,
    ThresholdAlert,
    normalize_phone_digits,
)
from .storage import ContactStorage
from .validation import ValidationError, sanitize_text, validate_contact_payload

LEGACY_HEADER_ALIASES: dict[str, str] = {
    "id": "contact_id",
    "contactid": "contact_id",
    "contact_id": "contact_id",
    "name": "full_name",
    "full_name": "full_name",
    "contact_name": "full_name",
    "org": "organization",
    "organization": "organization",
    "department": "organization",
    "agency": "organization",
    "cat": "category",
    "category": "category",
    "type": "category",
    "phone": "phone",
    "phone_number": "phone",
    "tel": "phone",
    "primary_phone": "phone",
    "alt_phone": "alternate_phone",
    "alternate_phone": "alternate_phone",
    "backup_phone": "alternate_phone",
    "secondary_phone": "alternate_phone",
    "email": "email",
    "email_address": "email",
    "priority": "priority_level",
    "priority_level": "priority_level",
    "response_time": "response_time_mins",
    "response_mins": "response_time_mins",
    "response_time_mins": "response_time_mins",
    "eta_mins": "response_time_mins",
    "availability": "availability",
    "hours": "availability",
    "schedule": "availability",
    "location": "location_zone",
    "zone": "location_zone",
    "location_zone": "location_zone",
    "last_verified": "last_verified_date",
    "last_verified_date": "last_verified_date",
    "verified_date": "last_verified_date",
    "verification_interval": "verification_interval_days",
    "verification_interval_days": "verification_interval_days",
    "review_days": "verification_interval_days",
    "trusted": "is_trusted",
    "is_trusted": "is_trusted",
    "status": "status",
    "notes": "notes",
    "remarks": "notes",
}


class EmergencyContactEngine:
    """Orchestrates contact CRUD, search, analytics, threshold alerts, and imports."""

    def __init__(self, storage: ContactStorage | None = None) -> None:
        self.storage = storage or ContactStorage()
        self.contacts, self.startup_warnings = self.storage.load_contacts()
        self._sync_overdue_statuses(save_if_changed=False)

    def reload(self) -> list[str]:
        """Reload contacts from disk and return any recovery warnings."""
        self.contacts, self.startup_warnings = self.storage.load_contacts()
        self._sync_overdue_statuses(save_if_changed=False)
        return self.startup_warnings

    def _sync_overdue_statuses(
        self,
        reference_date: date | None = None,
        *,
        save_if_changed: bool = True,
    ) -> int:
        """Flag active contacts whose verification deadline has lapsed."""
        changed = 0
        for contact in self.contacts:
            if (
                contact.status == "Active"
                and contact.is_verification_overdue(reference_date)
            ):
                contact.status = "Overdue Review"
                changed += 1
        if changed and save_if_changed:
            self.storage.save_contacts(self.contacts, log_event=False)
        return changed

    def next_contact_id(self) -> str:
        """Generate the next sequential ECO-XXX identifier."""
        max_num = 0
        for contact in self.contacts:
            parts = contact.contact_id.split("-")
            if len(parts) == 2 and parts[1].isdigit():
                max_num = max(max_num, int(parts[1]))
        return f"ECO-{max_num + 1:03d}"

    def list_contacts(
        self,
        *,
        sort_by: str = "priority",
        reverse: bool = False,
    ) -> list[EmergencyContact]:
        """Return contacts sorted by priority, name, response_time, id, or readiness."""
        key_map = {
            "priority": lambda c: (c.priority_level, c.response_time_mins, c.full_name.lower()),
            "name": lambda c: (c.full_name.lower(), c.contact_id),
            "response_time": lambda c: (c.response_time_mins, c.priority_level),
            "id": lambda c: c.contact_id,
            "readiness": lambda c: (-c.readiness_score(), c.priority_level),
            "verified": lambda c: (c.last_verified_date, c.contact_id),
        }
        key_fn = key_map.get(sort_by, key_map["priority"])
        return sorted(self.contacts, key=key_fn, reverse=reverse)

    def get_contact(self, contact_id: str) -> EmergencyContact | None:
        """Look up a single contact by ID (case-insensitive)."""
        target = contact_id.strip().upper()
        for contact in self.contacts:
            if contact.contact_id.upper() == target:
                return contact
        return None

    def find_phone_duplicates(
        self, phone: str, *, exclude_id: str | None = None
    ) -> list[EmergencyContact]:
        """Return existing contacts sharing the same normalized primary phone."""
        digits = normalize_phone_digits(phone)
        if not digits:
            return []
        matches: list[EmergencyContact] = []
        for contact in self.contacts:
            if exclude_id and contact.contact_id.upper() == exclude_id.upper():
                continue
            if contact.normalized_phone() == digits:
                matches.append(contact)
        return matches

    def add_contact(
        self,
        payload: dict[str, Any],
        *,
        allow_duplicate_phone: bool = True,
    ) -> EmergencyContact:
        """Validate, assign an ID if needed, persist, and log a new contact."""
        data = dict(payload)
        if not sanitize_text(data.get("contact_id", "")):
            data["contact_id"] = self.next_contact_id()

        now_iso = datetime.now().isoformat(timespec="seconds")
        data.setdefault("created_at", now_iso)
        data["updated_at"] = now_iso

        contact = validate_contact_payload(data, require_id=True)
        if self.get_contact(contact.contact_id):
            raise ValidationError(
                [f"Contact ID '{contact.contact_id}' already exists."]
            )
        if not allow_duplicate_phone and self.find_phone_duplicates(contact.phone):
            raise ValidationError(
                [f"A contact with phone '{contact.phone}' already exists."]
            )

        self.contacts.append(contact)
        self.storage.save_contacts(self.contacts)
        self.storage.append_audit_log(
            "ADD",
            f"Added {contact.contact_id} | {contact.full_name} ({contact.category}, P{contact.priority_level})",
        )
        return contact

    def update_contact(
        self, contact_id: str, updates: dict[str, Any]
    ) -> EmergencyContact:
        """Update an existing contact after full defensive validation."""
        existing = self.get_contact(contact_id)
        if not existing:
            raise KeyError(f"Contact '{contact_id}' was not found.")

        merged = existing.to_dict()
        merged.update(updates)
        merged["contact_id"] = existing.contact_id
        merged["created_at"] = existing.created_at
        merged["updated_at"] = datetime.now().isoformat(timespec="seconds")

        updated = validate_contact_payload(merged, require_id=True)
        idx = self.contacts.index(existing)
        self.contacts[idx] = updated
        self.storage.save_contacts(self.contacts)
        self.storage.append_audit_log(
            "UPDATE",
            f"Updated {updated.contact_id} | {updated.full_name} (status={updated.status})",
        )
        return updated

    def mark_verified(
        self, contact_id: str, verified_date: str | None = None
    ) -> EmergencyContact:
        """Refresh a contact's verification date and reactivate if overdue."""
        existing = self.get_contact(contact_id)
        if not existing:
            raise KeyError(f"Contact '{contact_id}' was not found.")
        target_date = verified_date or date.today().isoformat()
        new_status = (
            "Active" if existing.status == "Overdue Review" else existing.status
        )
        return self.update_contact(
            contact_id,
            {"last_verified_date": target_date, "status": new_status},
        )

    def delete_contact(self, contact_id: str) -> EmergencyContact:
        """Delete a contact by ID and persist changes."""
        existing = self.get_contact(contact_id)
        if not existing:
            raise KeyError(f"Contact '{contact_id}' was not found.")
        self.contacts.remove(existing)
        self.storage.save_contacts(self.contacts)
        self.storage.append_audit_log(
            "DELETE",
            f"Deleted {existing.contact_id} | {existing.full_name} ({existing.phone})",
        )
        return existing

    def search_contacts(
        self,
        *,
        keyword: str = "",
        category: str = "",
        max_priority: int | None = None,
        status: str = "",
        availability: str = "",
        trusted_only: bool = False,
        overdue_only: bool = False,
        reference_date: date | None = None,
    ) -> list[EmergencyContact]:
        """Filter and rank emergency contacts by relevance, priority, and speed."""
        query = sanitize_text(keyword, max_length=80).lower()
        query_digits = normalize_phone_digits(query)
        tokens = [tok for tok in query.split() if tok]

        scored_results: list[tuple[int, int, float, EmergencyContact]] = []

        for contact in self.contacts:
            if category and contact.category.lower() != category.lower():
                continue
            if max_priority is not None and contact.priority_level > max_priority:
                continue
            if status and contact.status.lower() != status.lower():
                continue
            if availability and contact.availability.lower() != availability.lower():
                continue
            if trusted_only and not contact.is_trusted:
                continue
            if overdue_only and not contact.is_verification_overdue(reference_date):
                continue

            relevance = 0
            if tokens:
                haystack = " ".join(
                    [
                        contact.contact_id,
                        contact.full_name,
                        contact.organization,
                        contact.category,
                        contact.phone,
                        contact.alternate_phone,
                        contact.email,
                        contact.location_zone,
                        contact.notes,
                    ]
                ).lower()
                digit_haystack = (
                    contact.normalized_phone()
                    + " "
                    + normalize_phone_digits(contact.alternate_phone)
                )

                matched_all = True
                for tok in tokens:
                    tok_digits = normalize_phone_digits(tok)
                    if tok in haystack:
                        relevance += 10
                        if tok in contact.full_name.lower():
                            relevance += 15
                        if tok == contact.contact_id.lower():
                            relevance += 30
                        if tok in contact.location_zone.lower():
                            relevance += 8
                    elif tok_digits and tok_digits in digit_haystack:
                        relevance += 20
                    else:
                        matched_all = False
                        break

                if not matched_all:
                    if query_digits and query_digits in digit_haystack:
                        relevance += 20
                    else:
                        continue

            scored_results.append(
                (
                    -relevance,
                    contact.priority_level,
                    contact.response_time_mins,
                    contact,
                )
            )

        scored_results.sort(key=lambda item: (item[0], item[1], item[2], item[3].full_name))
        return [item[3] for item in scored_results]

    def get_speed_dial(self, limit: int = 10) -> list[EmergencyContact]:
        """Return top critical, active, trusted 24/7 emergency contacts."""
        candidates = [
            c
            for c in self.contacts
            if c.status in {"Active", "Overdue Review"}
            and c.is_trusted
            and c.priority_level <= 2
        ]
        candidates.sort(
            key=lambda c: (
                0 if c.availability == "24/7" else 1,
                c.priority_level,
                c.response_time_mins,
                c.full_name,
            )
        )
        return candidates[:limit]

    def evaluate_threshold_alerts(
        self, reference_date: date | None = None
    ) -> list[ThresholdAlert]:
        """Detect overdue verification deadlines, SLA breaches, and record anomalies."""
        ref = reference_date or date.today()
        alerts: list[ThresholdAlert] = []

        phone_groups: dict[str, list[EmergencyContact]] = defaultdict(list)
        for contact in self.contacts:
            digits = contact.normalized_phone()
            if digits:
                phone_groups[digits].append(contact)

            # 1. Overdue verification deadline
            overdue_days = contact.days_overdue(ref)
            if overdue_days > 0:
                severity = "CRITICAL" if contact.priority_level <= 2 or overdue_days > 90 else "WARNING"
                alerts.append(
                    ThresholdAlert(
                        severity=severity,
                        code="OVERDUE_VERIFICATION",
                        contact_id=contact.contact_id,
                        contact_name=contact.full_name,
                        message=(
                            f"Verification overdue by {overdue_days} day(s) "
                            f"(last verified {contact.last_verified_date}, interval {contact.verification_interval_days}d)."
                        ),
                    )
                )

            # 2. Category SLA / response time breach
            sla_limit = CATEGORY_SLA_MAX_MINS.get(contact.category, 20.0)
            if contact.status != "Inactive" and contact.response_time_mins > sla_limit:
                severity = "CRITICAL" if contact.priority_level == 1 else "WARNING"
                alerts.append(
                    ThresholdAlert(
                        severity=severity,
                        code="SLA_RESPONSE_BREACH",
                        contact_id=contact.contact_id,
                        contact_name=contact.full_name,
                        message=(
                            f"Response time {contact.response_time_mins:.1f} min exceeds "
                            f"{contact.category} SLA limit ({sla_limit:.0f} min)."
                        ),
                    )
                )

            # 3. Critical priority without 24/7 coverage or backup phone
            if contact.priority_level == 1 and contact.status != "Inactive":
                if contact.availability != "24/7":
                    alerts.append(
                        ThresholdAlert(
                            severity="WARNING",
                            code="CRITICAL_LIMITED_HOURS",
                            contact_id=contact.contact_id,
                            contact_name=contact.full_name,
                            message=(
                                f"Priority 1 (Critical) contact only available '{contact.availability}', not 24/7."
                            ),
                        )
                    )
                if not contact.alternate_phone and len(contact.normalized_phone()) > 4:
                    alerts.append(
                        ThresholdAlert(
                            severity="INFO",
                            code="MISSING_BACKUP_PHONE",
                            contact_id=contact.contact_id,
                            contact_name=contact.full_name,
                            message="Priority 1 contact has no alternate/backup phone number.",
                        )
                    )

            # 4. Inactive yet marked trusted
            if contact.status == "Inactive" and contact.is_trusted:
                alerts.append(
                    ThresholdAlert(
                        severity="WARNING",
                        code="INACTIVE_TRUSTED",
                        contact_id=contact.contact_id,
                        contact_name=contact.full_name,
                        message="Contact is marked Trusted but status is Inactive.",
                    )
                )

        # 5. Duplicate primary phone numbers
        for digits, group in phone_groups.items():
            if len(group) > 1:
                ids = ", ".join(c.contact_id for c in group)
                for contact in group:
                    alerts.append(
                        ThresholdAlert(
                            severity="WARNING",
                            code="DUPLICATE_PHONE",
                            contact_id=contact.contact_id,
                            contact_name=contact.full_name,
                            message=f"Shares normalized phone '{digits}' with [{ids}].",
                        )
                    )

        severity_order = {"CRITICAL": 0, "WARNING": 1, "INFO": 2}
        alerts.sort(key=lambda a: (severity_order.get(a.severity, 9), a.contact_id, a.code))
        return alerts

    def generate_summary(
        self, reference_date: date | None = None
    ) -> SummaryMetrics:
        """Compute comprehensive executive metrics, trends, and alerts."""
        ref = reference_date or date.today()
        total = len(self.contacts)
        alerts = self.evaluate_threshold_alerts(ref)

        if total == 0:
            return SummaryMetrics(
                total_contacts=0,
                active_count=0,
                standby_count=0,
                overdue_status_count=0,
                inactive_count=0,
                trusted_count=0,
                twenty_four_seven_count=0,
                overdue_verification_count=0,
                critical_priority_count=0,
                avg_priority=0.0,
                avg_response_time_mins=0.0,
                median_response_time_mins=0.0,
                min_response_time_mins=0.0,
                max_response_time_mins=0.0,
                avg_readiness_score=0.0,
                avg_days_since_verified=0.0,
                category_counts={},
                category_avg_response={},
                priority_counts={p: 0 for p in range(1, 6)},
                status_counts={s: 0 for s in VALID_STATUSES},
                availability_counts={a: 0 for a in VALID_AVAILABILITIES},
                monthly_verification_trend={},
                alerts=alerts,
            )

        status_counter = Counter(c.status for c in self.contacts)
        category_counter = Counter(c.category for c in self.contacts)
        priority_counter = Counter(c.priority_level for c in self.contacts)
        availability_counter = Counter(c.availability for c in self.contacts)

        response_times = [c.response_time_mins for c in self.contacts]
        priorities = [c.priority_level for c in self.contacts]
        readiness_scores = [c.readiness_score(ref) for c in self.contacts]
        days_verified = [c.days_since_verified(ref) for c in self.contacts]

        cat_responses: dict[str, list[float]] = defaultdict(list)
        month_counter: Counter[str] = Counter()
        for c in self.contacts:
            cat_responses[c.category].append(c.response_time_mins)
            month_counter[c.last_verified_date[:7]] += 1

        category_avg_response = {
            cat: round(sum(vals) / len(vals), 2)
            for cat, vals in sorted(cat_responses.items())
        }

        return SummaryMetrics(
            total_contacts=total,
            active_count=status_counter.get("Active", 0),
            standby_count=status_counter.get("Standby", 0),
            overdue_status_count=status_counter.get("Overdue Review", 0),
            inactive_count=status_counter.get("Inactive", 0),
            trusted_count=sum(1 for c in self.contacts if c.is_trusted),
            twenty_four_seven_count=availability_counter.get("24/7", 0),
            overdue_verification_count=sum(
                1 for c in self.contacts if c.is_verification_overdue(ref)
            ),
            critical_priority_count=priority_counter.get(1, 0),
            avg_priority=round(sum(priorities) / total, 2),
            avg_response_time_mins=round(sum(response_times) / total, 2),
            median_response_time_mins=round(statistics.median(response_times), 2),
            min_response_time_mins=round(min(response_times), 2),
            max_response_time_mins=round(max(response_times), 2),
            avg_readiness_score=round(sum(readiness_scores) / total, 1),
            avg_days_since_verified=round(sum(days_verified) / total, 1),
            category_counts=dict(
                sorted(category_counter.items(), key=lambda x: (-x[1], x[0]))
            ),
            category_avg_response=category_avg_response,
            priority_counts={p: priority_counter.get(p, 0) for p in range(1, 6)},
            status_counts={s: status_counter.get(s, 0) for s in VALID_STATUSES},
            availability_counts={
                a: availability_counter.get(a, 0) for a in VALID_AVAILABILITIES
            },
            monthly_verification_trend=dict(sorted(month_counter.items())),
            alerts=alerts,
        )

    def import_csv(
        self,
        csv_path: str | Path,
        *,
        on_duplicate: str = "skip",  # "skip" or "update"
    ) -> ImportResult:
        """Ingest a legacy CSV file with header normalization and row-by-row error logs."""
        source = Path(csv_path)
        if not source.exists():
            raise FileNotFoundError(f"Import file not found: {source}")

        row_errors: list[RowError] = []
        total_rows = 0
        imported_count = 0
        updated_count = 0
        skipped_duplicate_count = 0

        with source.open("r", encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            if not reader.fieldnames:
                raise ValueError("CSV file contains no header row.")

            header_map: dict[str, str] = {}
            for raw_col in reader.fieldnames:
                normalized_col = raw_col.strip().lower().replace(" ", "_")
                if normalized_col in LEGACY_HEADER_ALIASES:
                    header_map[raw_col] = LEGACY_HEADER_ALIASES[normalized_col]

            for row_idx, raw_row in enumerate(reader, start=2):
                total_rows += 1
                mapped: dict[str, Any] = {}
                for raw_key, raw_val in raw_row.items():
                    if raw_key in header_map:
                        mapped[header_map[raw_key]] = raw_val

                raw_id = sanitize_text(mapped.get("contact_id", ""))
                raw_name = sanitize_text(mapped.get("full_name", ""))
                ident = raw_id or raw_name or f"Row {row_idx}"

                if not raw_id:
                    mapped["contact_id"] = self.next_contact_id()

                try:
                    candidate = validate_contact_payload(mapped, require_id=True)
                except ValidationError as exc:
                    row_errors.append(
                        RowError(
                            row_number=row_idx,
                            raw_identifier=ident,
                            errors=exc.errors,
                        )
                    )
                    continue

                existing = self.get_contact(candidate.contact_id)
                if not existing:
                    phone_matches = self.find_phone_duplicates(candidate.phone)
                    if phone_matches and on_duplicate == "skip":
                        skipped_duplicate_count += 1
                        row_errors.append(
                            RowError(
                                row_number=row_idx,
                                raw_identifier=ident,
                                errors=[
                                    f"Skipped duplicate phone matching {phone_matches[0].contact_id}."
                                ],
                            )
                        )
                        continue
                    self.contacts.append(candidate)
                    imported_count += 1
                else:
                    if on_duplicate == "update":
                        idx = self.contacts.index(existing)
                        candidate.created_at = existing.created_at
                        candidate.updated_at = datetime.now().isoformat(
                            timespec="seconds"
                        )
                        self.contacts[idx] = candidate
                        updated_count += 1
                    else:
                        skipped_duplicate_count += 1
                        row_errors.append(
                            RowError(
                                row_number=row_idx,
                                raw_identifier=ident,
                                errors=[
                                    f"Skipped duplicate contact_id '{candidate.contact_id}'."
                                ],
                            )
                        )

        self.storage.save_contacts(self.contacts, log_event=False)

        error_log_path = ""
        if row_errors:
            stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            log_file = self.storage.logs_dir / f"import_errors_{stamp}.log"
            lines = [
                f"Bulk CSV Import Error Log — Source: {source.name}",
                f"Generated: {datetime.now().isoformat(timespec='seconds')}",
                f"Total Rows: {total_rows} | Imported: {imported_count} | Updated: {updated_count} | "
                f"Skipped Duplicates: {skipped_duplicate_count} | Failed: {len(row_errors) - skipped_duplicate_count}",
                "=" * 72,
            ]
            for err in row_errors:
                lines.append(
                    f"Line {err.row_number} [{err.raw_identifier}]: "
                    + "; ".join(err.errors)
                )
            log_file.write_text("\n".join(lines) + "\n", encoding="utf-8")
            error_log_path = str(log_file)

        failed_count = len(row_errors) - skipped_duplicate_count
        self.storage.append_audit_log(
            "IMPORT",
            (
                f"CSV '{source.name}': total={total_rows}, imported={imported_count}, "
                f"updated={updated_count}, skipped={skipped_duplicate_count}, failed={failed_count}"
            ),
        )

        return ImportResult(
            source_file=str(source),
            total_rows=total_rows,
            imported_count=imported_count,
            updated_count=updated_count,
            skipped_duplicate_count=skipped_duplicate_count,
            failed_count=failed_count,
            row_errors=row_errors,
            error_log_path=error_log_path,
        )
