# Emergency Contact Organizer (Project #71 — CampusSolve)

**Domain:** Safety & Community  
**Tech Stack:** Python 3.10+ Standard Library (`dataclasses`, `datetime`, `collections`, `csv`, `json`, `re`, `statistics`, `tkinter`, `unittest`) — **zero external dependencies**.

---

## Key Features Implemented

### Core Features (Must-Have)
- **Interactive Terminal Interface (`emergency_organizer/cli.py`)**: Menu-driven command prompt with branded welcome screen, ANSI color support (`--no-color` option), fixed-width column-separated tables, and interactive pagination.
- **Defensive Input Validation (`emergency_organizer/validation.py`)**: Real-time sanitization, regex checks, range validation, CSV formula injection protection, and centralized looping terminal input wrappers that prevent crashes on blank, non-numeric, or out-of-range inputs.
- **Core Business Logic Engine (`emergency_organizer/engine.py`)**: Structured `EmergencyContact` dataclass, sequential `ECO-XXX` ID generation, readiness scoring, relevance-ranked multi-criteria search, emergency speed-dial ranking, and executive metrics aggregation.
- **Local Data Persistence (`emergency_organizer/storage.py`)**: Synchronized atomic JSON (`data/contacts.json`) and CSV (`data/contacts.csv`) storage with automatic recovery/backup on missing or corrupted (`JSONDecodeError` / `FileNotFoundError`) files.
- **Record Query & Search**: Keyword, category, priority level, status, availability, trusted-only, and overdue filtering.
- **Executive Summary Generation**: Totals, averages, medians, min/max response times, readiness score, category/priority distributions, monthly verification trends, and ASCII bar charts.

### Stretch Features (Good-to-Have)
- **Multi-Format Summary Export (`emergency_organizer/exporter.py`)**: Generates structured Markdown reports (`.md`), plain-text audit reports (`.txt`), standardized CSV analytics reports (`.csv`), standalone HTML/SVG visual dashboards (`.html`), and optional Matplotlib PNG charts.
- **Threshold Warning Indicators**: Automated `[CRITICAL]`, `[WARNING]`, and `[INFO]` flags for overdue verification deadlines, category SLA response-time breaches, non-24/7 critical contacts, missing backup phones, inactive trusted contacts, and duplicate phone numbers.
- **Bulk Dataset Import**: Legacy CSV ingestion with automatic column-alias mapping, defensive validation, duplicate handling (`skip`/`update`), and detailed row-by-row error logs in `logs/`.
- **Interactive Tkinter GUI (`emergency_organizer/gui.py`)**: Optional lightweight graphical interface (`python main.py --gui` or menu option `11`) featuring live search/filtering, modal Add/Edit dialogs, Canvas bar charts, threshold alerts, CSV import, and multi-format export.

---

## Project Structure

```text
emergency_contact_organizer/
├── main.py                        # CLI / GUI / Demo entry point
├── requirements.txt               # Zero external dependencies
├── pyproject.toml                 # Project metadata
├── README.md
├── emergency_organizer/
│   ├── __init__.py
│   ├── models.py                  # Dataclasses, domain schemas & readiness scoring
│   ├── validation.py              # Sanitization, regex/range checks & input wrappers
│   ├── storage.py                 # JSON/CSV persistence, corruption recovery & audit log
│   ├── engine.py                  # CRUD, search, analytics, alerts & bulk CSV import
│   ├── exporter.py                # Markdown, TXT audit, CSV, HTML/SVG chart exports
│   ├── cli.py                     # Interactive terminal UI with pagination & ASCII charts
│   └── gui.py                     # Optional Tkinter GUI
├── data/
│   ├── contacts.json              # Active JSON store (seeded with 42 realistic records)
│   ├── contacts.csv               # Active CSV store (synced with JSON)
│   ├── sample_contacts.json       # Pristine 42-record sample dataset (JSON)
│   ├── sample_contacts.csv        # Pristine 42-record sample dataset (CSV)
│   └── legacy_import_sample.csv   # Sample legacy CSV with valid + invalid rows
├── exports/                       # Generated reports (MD, TXT, CSV, HTML)
├── logs/                          # Audit logs and bulk import error logs
└── tests/                         # Unit & end-to-end test suite
```

---

## Quick Start

### 1. Optional Virtual Environment Setup
```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS / Linux:
source .venv/bin/activate
```
*(No `pip install` is required — the application runs strictly on Python 3.10+ Standard Library.)*

### 2. Run Interactive Terminal App
```bash
python main.py
```

### 3. Run Optional Tkinter GUI
```bash
python main.py --gui
```

### 4. Run Non-Interactive Demo Showcase
```bash
python main.py --demo
```

### 5. Run Full Test Suite
```bash
python -m unittest discover -s tests -v
```
