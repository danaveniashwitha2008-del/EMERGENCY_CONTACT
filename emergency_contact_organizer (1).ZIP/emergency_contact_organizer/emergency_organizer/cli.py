"""Interactive menu-driven Terminal Interface with ANSI formatting & pagination."""

from __future__ import annotations

from datetime import date
import os
from pathlib import Path
import sys
from typing import Callable, Sequence

from . import __app_name__, __project_id__, __version__
from .engine import EmergencyContactEngine
from .exporter import SummaryExporter
from .models import (
    PRIORITY_LABELS,
    VALID_AVAILABILITIES,
    VALID_CATEGORIES,
    VALID_STATUSES,
    EmergencyContact,
)
from .validation import (
    InputCancelled,
    ValidationError,
    prompt_choice,
    prompt_validated,
    prompt_yes_no,
    validate_category,
    validate_date_iso,
    validate_email,
    validate_full_name,
    validate_location_zone,
    validate_notes,
    validate_organization,
    validate_phone,
    validate_priority,
    validate_response_time,
    validate_verification_interval,
)


def _supports_ansi() -> bool:
    """Detect whether ANSI color sequences are likely supported."""
    if os.environ.get("NO_COLOR"):
        return False
    if os.name == "nt":
        # Windows 10+ VT mode check
        try:
            import ctypes

            kernel32 = ctypes.windll.kernel32
            handle = kernel32.GetStdHandle(-11)
            mode = ctypes.c_uint32()
            if kernel32.GetConsoleMode(handle, ctypes.byref(mode)):
                kernel32.SetConsoleMode(handle, mode.value | 0x0004)
                return True
        except Exception:
            pass
    return hasattr(sys.stdout, "isatty") and sys.stdout.isatty()


class Theme:
    """ANSI color helper with clean no-color fallback."""

    def __init__(self, enabled: bool = True) -> None:
        self.enabled = enabled

    def wrap(self, text: str, code: str) -> str:
        if not self.enabled:
            return text
        return f"\033[{code}m{text}\033[0m"

    def bold(self, text: str) -> str:
        return self.wrap(text, "1")

    def cyan(self, text: str) -> str:
        return self.wrap(text, "36")

    def green(self, text: str) -> str:
        return self.wrap(text, "32")

    def yellow(self, text: str) -> str:
        return self.wrap(text, "33")

    def red(self, text: str) -> str:
        return self.wrap(text, "31")

    def dim(self, text: str) -> str:
        return self.wrap(text, "2")


def _truncate(text: str, width: int) -> str:
    """Truncate text cleanly to fixed column width."""
    if len(text) <= width:
        return text.ljust(width)
    if width <= 3:
        return text[:width]
    return (text[: width - 3] + "...").ljust(width)


class EmergencyCLI:
    """Menu-driven terminal application for Emergency Contact Organizer."""

    def __init__(
        self,
        engine: EmergencyContactEngine,
        exporter: SummaryExporter,
        *,
        use_color: bool | None = None,
        page_size: int = 12,
        input_fn: Callable[[str], str] = input,
        output_fn: Callable[[str], None] = print,
    ) -> None:
        self.engine = engine
        self.exporter = exporter
        self.theme = Theme(
            enabled=_supports_ansi() if use_color is None else use_color
        )
        self.page_size = max(5, page_size)
        self.input_fn = input_fn
        self.output_fn = output_fn

    def out(self, text: str = "") -> None:
        self.output_fn(text)

    def render_banner(self) -> None:
        """Display branded welcome screen and live repository status."""
        border = "=" * 78
        self.out(self.theme.cyan(border))
        self.out(
            self.theme.bold(
                f"  {__app_name__.upper()} v{__version__}  |  {__project_id__}"
            )
        )
        self.out(
            self.theme.dim(
                "  Domain: Safety & Community  |  Zero-Dependency Local Storage (JSON + CSV)"
            )
        )
        self.out(self.theme.cyan(border))

        if self.engine.startup_warnings:
            for warn in self.engine.startup_warnings:
                self.out(self.theme.yellow(f"  [Startup Notice] {warn}"))

        alerts = self.engine.evaluate_threshold_alerts()
        critical_alerts = sum(1 for a in alerts if a.severity == "CRITICAL")
        total = len(self.engine.contacts)
        status_line = (
            f"  Loaded Contacts: {total}  |  "
            f"Threshold Alerts: {len(alerts)} ({critical_alerts} critical)"
        )
        if critical_alerts > 0:
            self.out(self.theme.yellow(status_line))
        else:
            self.out(self.theme.green(status_line))
        self.out()

    def render_menu(self) -> None:
        """Print the main navigation menu."""
        self.out(self.theme.bold("MAIN MENU"))
        self.out("-" * 78)
        items = [
            ("1", "View All Contacts (Paginated Table)"),
            ("2", "Emergency Speed-Dial (Top Critical 24/7 Contacts)"),
            ("3", "Search & Filter Contacts (Keyword / Category / Priority / Status)"),
            ("4", "Add New Emergency Contact (Guided Validation)"),
            ("5", "Update or Verify Existing Contact"),
            ("6", "Delete Contact"),
            ("7", "Executive Summary & Analytics (Metrics, Trends & ASCII Charts)"),
            ("8", "Threshold Warning Indicators & Anomaly Audit"),
            ("9", "Bulk CSV Dataset Import (With Row-by-Row Error Log)"),
            ("10", "Multi-Format Summary Export (Markdown / Audit TXT / CSV / HTML Chart)"),
            ("11", "Launch Graphical Interface (Tkinter GUI)"),
            ("12", "View Recent Audit Log"),
            ("0", "Exit"),
        ]
        for key, label in items:
            self.out(f"  [{self.theme.cyan(key.rjust(2))}] {label}")
        self.out("-" * 78)

    def run(self) -> None:
        """Primary navigation dispatch loop."""
        self.render_banner()
        while True:
            self.render_menu()
            try:
                choice = self.input_fn("Choose an option [0-12]: ").strip()
            except (EOFError, KeyboardInterrupt):
                self.out("\nExiting Emergency Contact Organizer. Stay safe!")
                break

            handlers: dict[str, Callable[[], None]] = {
                "1": self.handle_view_all,
                "2": self.handle_speed_dial,
                "3": self.handle_search,
                "4": self.handle_add,
                "5": self.handle_update,
                "6": self.handle_delete,
                "7": self.handle_summary,
                "8": self.handle_alerts,
                "9": self.handle_bulk_import,
                "10": self.handle_export,
                "11": self.handle_launch_gui,
                "12": self.handle_view_audit_log,
            }

            if choice == "0":
                self.engine.storage.save_contacts(
                    self.engine.contacts, log_event=False
                )
                self.out(
                    self.theme.green(
                        "All records safely persisted to JSON & CSV. Goodbye!"
                    )
                )
                break
            elif choice in handlers:
                try:
                    handlers[choice]()
                except InputCancelled:
                    self.out(self.theme.yellow("\n  [Cancelled] Returned to main menu.\n"))
                except Exception as exc:
                    self.out(self.theme.red(f"\n  [Error] Unexpected failure: {exc}\n"))
            else:
                self.out(
                    self.theme.yellow(
                        "  [!] Invalid menu selection. Enter a number from 0 to 12.\n"
                    )
                )

    def display_contacts_table(
        self,
        contacts: Sequence[EmergencyContact],
        *,
        title: str = "Contacts",
        interactive_pagination: bool = True,
    ) -> None:
        """Render a fixed-width table with column separators and optional pagination."""
        if not contacts:
            self.out(self.theme.yellow(f"\n  No matching contacts found for '{title}'.\n"))
            return

        total = len(contacts)
        total_pages = max(1, (total + self.page_size - 1) // self.page_size)
        page = 0

        header = (
            f"{'ID':<8} | {'Name':<24} | {'Category':<20} | "
            f"{'Phone':<15} | {'P':<2} | {'ETA':<6} | {'Avail':<11} | {'Status':<14}"
        )
        divider = "-" * len(header)

        while True:
            start = page * self.page_size
            end = min(start + self.page_size, total)
            chunk = contacts[start:end]

            self.out()
            self.out(
                self.theme.bold(
                    f"{title} — Showing {start + 1}-{end} of {total} (Page {page + 1}/{total_pages})"
                )
            )
            self.out(divider)
            self.out(self.theme.bold(header))
            self.out(divider)

            for c in chunk:
                row = (
                    f"{_truncate(c.contact_id, 8)} | "
                    f"{_truncate(c.full_name, 24)} | "
                    f"{_truncate(c.category, 20)} | "
                    f"{_truncate(c.phone, 15)} | "
                    f"P{c.priority_level} | "
                    f"{c.response_time_mins:>5.1f}m | "
                    f"{_truncate(c.availability, 11)} | "
                    f"{_truncate(c.status, 14)}"
                )
                if c.status == "Overdue Review":
                    self.out(self.theme.yellow(row))
                elif c.status == "Inactive":
                    self.out(self.theme.dim(row))
                elif c.priority_level == 1:
                    self.out(self.theme.red(row))
                else:
                    self.out(row)
            self.out(divider)

            if not interactive_pagination:
                self.out()
                break

            nav_hints = ["[V]iew details by ID", "[Q]uit table"]
            if page < total_pages - 1:
                nav_hints.insert(0, "[N]ext page")
            if page > 0:
                nav_hints.insert(0, "[P]revious page")

            try:
                cmd = self.input_fn("  " + " | ".join(nav_hints) + ": ").strip().lower()
            except (EOFError, KeyboardInterrupt):
                break

            if cmd in {"", "q", "quit", "back"}:
                break
            elif cmd in {"n", "next"} and page < total_pages - 1:
                page += 1
            elif cmd in {"p", "prev", "previous"} and page > 0:
                page -= 1
            elif cmd.startswith("v"):
                cid = cmd[1:].strip()
                if not cid:
                    cid = self.input_fn("  Enter Contact ID (e.g., ECO-001): ").strip()
                contact = self.engine.get_contact(cid)
                if contact:
                    self.display_contact_detail(contact)
                else:
                    self.out(self.theme.yellow(f"  [!] Contact '{cid}' not found."))
            else:
                self.out(self.theme.yellow("  [!] Unrecognized navigation option."))

    def display_contact_detail(self, c: EmergencyContact) -> None:
        """Render complete details for a single contact."""
        self.out()
        self.out(self.theme.cyan("=" * 68))
        self.out(self.theme.bold(f"  {c.contact_id} — {c.full_name}"))
        self.out(self.theme.cyan("-" * 68))
        fields = [
            ("Organization", c.organization),
            ("Category", c.category),
            ("Primary Phone", c.phone),
            ("Alternate Phone", c.alternate_phone or "—"),
            ("Email", c.email or "—"),
            ("Priority", f"P{c.priority_level} ({c.priority_label()})"),
            ("Avg Response Time", f"{c.response_time_mins:.1f} mins"),
            ("Availability", c.availability),
            ("Location / Zone", c.location_zone),
            ("Last Verified", f"{c.last_verified_date} (every {c.verification_interval_days}d)"),
            ("Next Review Due", c.next_review_date().isoformat()),
            ("Overdue Days", str(c.days_overdue())),
            ("Trusted Contact", "Yes" if c.is_trusted else "No"),
            ("Status", c.status),
            ("Readiness Score", f"{c.readiness_score():.1f} / 100"),
            ("Notes", c.notes or "—"),
            ("Updated At", c.updated_at),
        ]
        for label, val in fields:
            self.out(f"  {label:<18}: {val}")
        self.out(self.theme.cyan("=" * 68))

    def handle_view_all(self) -> None:
        sort_choice = prompt_choice(
            "Sort contacts by",
            ["priority", "name", "response_time", "readiness", "verified", "id"],
            default="priority",
            input_fn=self.input_fn,
            output_fn=self.output_fn,
        )
        contacts = self.engine.list_contacts(sort_by=sort_choice)
        self.display_contacts_table(
            contacts, title=f"All Contacts (Sorted by {sort_choice})"
        )

    def handle_speed_dial(self) -> None:
        top = self.engine.get_speed_dial(limit=10)
        self.display_contacts_table(
            top,
            title="Emergency Speed-Dial (Critical & High Priority Trusted Contacts)",
            interactive_pagination=False,
        )

    def handle_search(self) -> None:
        self.out("\n" + self.theme.bold("SEARCH & FILTER CONTACTS"))
        keyword = self.input_fn(
            "  Keyword (name, org, phone, zone, ID, or blank for all): "
        ).strip()

        cat_options = ["All Categories", *VALID_CATEGORIES]
        cat_choice = prompt_choice(
            "Filter by Category",
            cat_options,
            default="All Categories",
            input_fn=self.input_fn,
            output_fn=self.output_fn,
        )
        category = "" if cat_choice == "All Categories" else cat_choice

        prio_raw = prompt_validated(
            "Max priority level (1-5, or 'all')",
            lambda v: 0 if v.lower() in {"", "all"} else validate_priority(v),
            default="all",
            input_fn=self.input_fn,
            output_fn=self.output_fn,
        )
        max_priority = None if prio_raw == 0 else prio_raw

        status_options = ["All Statuses", *VALID_STATUSES]
        status_choice = prompt_choice(
            "Filter by Status",
            status_options,
            default="All Statuses",
            input_fn=self.input_fn,
            output_fn=self.output_fn,
        )
        status = "" if status_choice == "All Statuses" else status_choice

        trusted_only = prompt_yes_no(
            "Only trusted contacts?",
            default=False,
            input_fn=self.input_fn,
            output_fn=self.output_fn,
        )

        results = self.engine.search_contacts(
            keyword=keyword,
            category=category,
            max_priority=max_priority,
            status=status,
            trusted_only=trusted_only,
        )
        self.display_contacts_table(results, title="Search Results")

    def handle_add(self) -> None:
        self.out("\n" + self.theme.bold("ADD NEW EMERGENCY CONTACT"))
        self.out(self.theme.dim("  Type 'cancel' at any prompt to abort.\n"))

        suggested_id = self.engine.next_contact_id()
        full_name = prompt_validated(
            "Full Name / Service Title",
            validate_full_name,
            input_fn=self.input_fn,
            output_fn=self.output_fn,
        )
        organization = prompt_validated(
            "Organization / Department",
            validate_organization,
            input_fn=self.input_fn,
            output_fn=self.output_fn,
        )
        category = prompt_choice(
            "Category",
            VALID_CATEGORIES,
            default=VALID_CATEGORIES[0],
            input_fn=self.input_fn,
            output_fn=self.output_fn,
        )
        phone = prompt_validated(
            "Primary Phone (e.g., 911 or +1-555-0140)",
            lambda v: validate_phone(v, required=True),
            input_fn=self.input_fn,
            output_fn=self.output_fn,
        )

        dups = self.engine.find_phone_duplicates(phone)
        if dups:
            self.out(
                self.theme.yellow(
                    f"  [Warning] Phone '{phone}' matches existing contact {dups[0].contact_id} ({dups[0].full_name})."
                )
            )
            if not prompt_yes_no(
                "Continue adding anyway?",
                default=False,
                input_fn=self.input_fn,
                output_fn=self.output_fn,
            ):
                raise InputCancelled()

        alt_phone = prompt_validated(
            "Alternate / Backup Phone (optional, press Enter to skip)",
            lambda v: validate_phone(v, required=False),
            default="",
            input_fn=self.input_fn,
            output_fn=self.output_fn,
        )
        email = prompt_validated(
            "Email Address (optional, press Enter to skip)",
            validate_email,
            default="",
            input_fn=self.input_fn,
            output_fn=self.output_fn,
        )
        priority = prompt_validated(
            "Priority Level (1=Critical .. 5=Low)",
            validate_priority,
            default="2",
            input_fn=self.input_fn,
            output_fn=self.output_fn,
        )
        response_mins = prompt_validated(
            "Expected Response Time (minutes, 0-1440)",
            validate_response_time,
            default="10",
            input_fn=self.input_fn,
            output_fn=self.output_fn,
        )
        availability = prompt_choice(
            "Availability Window",
            VALID_AVAILABILITIES,
            default="24/7",
            input_fn=self.input_fn,
            output_fn=self.output_fn,
        )
        location_zone = prompt_validated(
            "Location / Campus Zone",
            validate_location_zone,
            default="Campus-Wide",
            input_fn=self.input_fn,
            output_fn=self.output_fn,
        )
        last_verified = prompt_validated(
            "Last Verified Date (YYYY-MM-DD)",
            lambda v: validate_date_iso(v, allow_future=False),
            default=date.today().isoformat(),
            input_fn=self.input_fn,
            output_fn=self.output_fn,
        )
        interval_days = prompt_validated(
            "Verification Interval (days, 1-730)",
            validate_verification_interval,
            default="180",
            input_fn=self.input_fn,
            output_fn=self.output_fn,
        )
        is_trusted = prompt_yes_no(
            "Mark as Trusted Emergency Contact?",
            default=True,
            input_fn=self.input_fn,
            output_fn=self.output_fn,
        )
        status = prompt_choice(
            "Initial Status",
            VALID_STATUSES,
            default="Active",
            input_fn=self.input_fn,
            output_fn=self.output_fn,
        )
        notes = prompt_validated(
            "Notes / Dispatch Instructions (optional)",
            validate_notes,
            default="",
            input_fn=self.input_fn,
            output_fn=self.output_fn,
        )

        created = self.engine.add_contact(
            {
                "contact_id": suggested_id,
                "full_name": full_name,
                "organization": organization,
                "category": category,
                "phone": phone,
                "alternate_phone": alt_phone,
                "email": email,
                "priority_level": priority,
                "response_time_mins": response_mins,
                "availability": availability,
                "location_zone": location_zone,
                "last_verified_date": last_verified,
                "verification_interval_days": interval_days,
                "is_trusted": is_trusted,
                "status": status,
                "notes": notes,
            }
        )
        self.out(
            self.theme.green(
                f"\n  [Saved] Added {created.contact_id} — {created.full_name} "
                f"(Readiness: {created.readiness_score():.1f}/100)\n"
            )
        )

    def handle_update(self) -> None:
        cid = prompt_validated(
            "Enter Contact ID to update (e.g., ECO-001)",
            lambda v: v.strip().upper() if v.strip() else (_ for _ in ()).throw(ValueError("ID cannot be blank.")),
            input_fn=self.input_fn,
            output_fn=self.output_fn,
        )
        contact = self.engine.get_contact(cid)
        if not contact:
            self.out(self.theme.yellow(f"  [!] Contact '{cid}' not found.\n"))
            return

        self.display_contact_detail(contact)
        action = prompt_choice(
            "Update Action",
            [
                "Mark Verified Today (Quick Refresh)",
                "Edit Contact Fields",
                "Cancel",
            ],
            default="Mark Verified Today (Quick Refresh)",
            input_fn=self.input_fn,
            output_fn=self.output_fn,
        )
        if action == "Cancel":
            return
        if action.startswith("Mark Verified"):
            updated = self.engine.mark_verified(contact.contact_id)
            self.out(
                self.theme.green(
                    f"\n  [Verified] {updated.contact_id} verified on {updated.last_verified_date} (Status: {updated.status}).\n"
                )
            )
            return

        self.out(self.theme.dim("  Press Enter to keep current value."))
        updates: dict[str, object] = {}
        updates["full_name"] = prompt_validated(
            "Full Name",
            validate_full_name,
            default=contact.full_name,
            input_fn=self.input_fn,
            output_fn=self.output_fn,
        )
        updates["organization"] = prompt_validated(
            "Organization",
            validate_organization,
            default=contact.organization,
            input_fn=self.input_fn,
            output_fn=self.output_fn,
        )
        updates["category"] = prompt_choice(
            "Category",
            VALID_CATEGORIES,
            default=contact.category,
            input_fn=self.input_fn,
            output_fn=self.output_fn,
        )
        updates["phone"] = prompt_validated(
            "Primary Phone",
            lambda v: validate_phone(v, required=True),
            default=contact.phone,
            input_fn=self.input_fn,
            output_fn=self.output_fn,
        )
        updates["priority_level"] = prompt_validated(
            "Priority (1-5)",
            validate_priority,
            default=str(contact.priority_level),
            input_fn=self.input_fn,
            output_fn=self.output_fn,
        )
        updates["response_time_mins"] = prompt_validated(
            "Response Time (mins)",
            validate_response_time,
            default=str(contact.response_time_mins),
            input_fn=self.input_fn,
            output_fn=self.output_fn,
        )
        updates["availability"] = prompt_choice(
            "Availability",
            VALID_AVAILABILITIES,
            default=contact.availability,
            input_fn=self.input_fn,
            output_fn=self.output_fn,
        )
        updates["status"] = prompt_choice(
            "Status",
            VALID_STATUSES,
            default=contact.status,
            input_fn=self.input_fn,
            output_fn=self.output_fn,
        )
        updates["notes"] = prompt_validated(
            "Notes",
            validate_notes,
            default=contact.notes,
            input_fn=self.input_fn,
            output_fn=self.output_fn,
        )

        try:
            updated = self.engine.update_contact(contact.contact_id, updates)
            self.out(
                self.theme.green(
                    f"\n  [Updated] {updated.contact_id} saved successfully.\n"
                )
            )
        except ValidationError as exc:
            self.out(self.theme.red(f"\n  [!] Validation failed: {exc}\n"))

    def handle_delete(self) -> None:
        cid = prompt_validated(
            "Enter Contact ID to delete",
            lambda v: v.strip().upper() if v.strip() else (_ for _ in ()).throw(ValueError("ID cannot be blank.")),
            input_fn=self.input_fn,
            output_fn=self.output_fn,
        )
        contact = self.engine.get_contact(cid)
        if not contact:
            self.out(self.theme.yellow(f"  [!] Contact '{cid}' not found.\n"))
            return
        self.display_contact_detail(contact)
        if prompt_yes_no(
            f"Permanently delete {contact.contact_id} ({contact.full_name})?",
            default=False,
            input_fn=self.input_fn,
            output_fn=self.output_fn,
        ):
            self.engine.delete_contact(contact.contact_id)
            self.out(self.theme.green(f"\n  [Deleted] Removed {contact.contact_id}.\n"))

    def handle_summary(self) -> None:
        summary = self.engine.generate_summary()
        self.out()
        self.out(self.theme.cyan("=" * 78))
        self.out(self.theme.bold("  EXECUTIVE SUMMARY & OPERATIONAL ANALYTICS"))
        self.out(self.theme.cyan("=" * 78))

        if summary.total_contacts == 0:
            self.out(self.theme.yellow("  No contacts stored yet.\n"))
            return

        kpi_rows = [
            ("Total Stored Contacts", str(summary.total_contacts)),
            (
                "Status Breakdown",
                f"Active: {summary.active_count} | Standby: {summary.standby_count} | "
                f"Overdue: {summary.overdue_status_count} | Inactive: {summary.inactive_count}",
            ),
            (
                "Trusted / 24-7 Coverage",
                f"{summary.trusted_count}/{summary.total_contacts} trusted | "
                f"{summary.twenty_four_seven_count}/{summary.total_contacts} 24/7",
            ),
            (
                "Response Time (mins)",
                f"Avg: {summary.avg_response_time_mins:.2f} | Median: {summary.median_response_time_mins:.2f} | "
                f"Min: {summary.min_response_time_mins:.1f} | Max: {summary.max_response_time_mins:.1f}",
            ),
            ("Average Priority Level", f"{summary.avg_priority:.2f} (1=Critical, 5=Low)"),
            ("Average Readiness Score", f"{summary.avg_readiness_score:.1f} / 100"),
            (
                "Verification Health",
                f"Avg age: {summary.avg_days_since_verified:.1f}d | Overdue: {summary.overdue_verification_count}",
            ),
            ("Active Threshold Alerts", str(len(summary.alerts))),
        ]
        for label, val in kpi_rows:
            self.out(f"  {label:<25}: {val}")

        self.out("\n" + self.theme.bold("  CATEGORY DISTRIBUTION & AVG ETA (ASCII CHART)"))
        self.out("  " + "-" * 74)
        max_count = max(summary.category_counts.values(), default=1)
        for cat, count in summary.category_counts.items():
            bar_len = int((count / max_count) * 24) if max_count else 0
            bar = "#" * max(1, bar_len)
            avg_eta = summary.category_avg_response.get(cat, 0.0)
            self.out(
                f"  {cat:<24} | {bar:<24} | {count:>2} ({avg_eta:>5.1f}m avg)"
            )

        self.out("\n" + self.theme.bold("  PRIORITY DISTRIBUTION"))
        self.out("  " + "-" * 50)
        for prio in range(1, 6):
            cnt = summary.priority_counts.get(prio, 0)
            bar = "#" * min(20, cnt)
            self.out(
                f"  P{prio} ({PRIORITY_LABELS[prio]:<8}) | {bar:<20} | {cnt}"
            )

        if summary.monthly_verification_trend:
            self.out("\n" + self.theme.bold("  MONTHLY VERIFICATION TREND"))
            self.out("  " + "-" * 50)
            for month, cnt in list(summary.monthly_verification_trend.items())[-8:]:
                self.out(f"  {month} | {'*' * min(25, cnt):<25} | {cnt} verified")

        self.out(self.theme.cyan("=" * 78) + "\n")

    def handle_alerts(self) -> None:
        alerts = self.engine.evaluate_threshold_alerts()
        self.out()
        self.out(self.theme.bold(f"THRESHOLD WARNING INDICATORS ({len(alerts)} total)"))
        self.out("-" * 78)
        if not alerts:
            self.out(self.theme.green("  [OK] All contacts pass threshold & SLA checks.\n"))
            return

        for alert in alerts:
            tag = f"[{alert.severity:<8}]"
            line = f"  {tag} {alert.contact_id} | {alert.contact_name:<22} | {alert.message}"
            if alert.severity == "CRITICAL":
                self.out(self.theme.red(line))
            elif alert.severity == "WARNING":
                self.out(self.theme.yellow(line))
            else:
                self.out(self.theme.cyan(line))
        self.out("-" * 78 + "\n")

    def handle_bulk_import(self) -> None:
        self.out("\n" + self.theme.bold("BULK CSV DATASET IMPORT"))
        default_sample = str(Path("data") / "legacy_import_sample.csv")
        csv_path = prompt_validated(
            "Path to legacy CSV file",
            lambda v: v.strip() if v.strip() else (_ for _ in ()).throw(ValueError("Path cannot be blank.")),
            default=default_sample if Path(default_sample).exists() else None,
            input_fn=self.input_fn,
            output_fn=self.output_fn,
        )
        dup_mode = prompt_choice(
            "Duplicate ID / Phone Policy",
            ["skip", "update"],
            default="skip",
            input_fn=self.input_fn,
            output_fn=self.output_fn,
        )
        try:
            result = self.engine.import_csv(csv_path, on_duplicate=dup_mode)
        except (FileNotFoundError, ValueError) as exc:
            self.out(self.theme.red(f"\n  [Import Error] {exc}\n"))
            return

        self.out("\n" + self.theme.cyan("-" * 68))
        self.out(f"  Source File         : {result.source_file}")
        self.out(f"  Total Rows Scanned  : {result.total_rows}")
        self.out(self.theme.green(f"  Imported New        : {result.imported_count}"))
        self.out(self.theme.cyan(f"  Updated Existing    : {result.updated_count}"))
        self.out(self.theme.yellow(f"  Skipped Duplicates  : {result.skipped_duplicate_count}"))
        self.out(self.theme.red(f"  Validation Failures : {result.failed_count}"))
        if result.error_log_path:
            self.out(f"  Detailed Error Log  : {result.error_log_path}")
        if result.row_errors:
            self.out("\n  Row-by-Row Issues (first 10):")
            for err in result.row_errors[:10]:
                self.out(
                    self.theme.yellow(
                        f"    Line {err.row_number} [{err.raw_identifier}]: {'; '.join(err.errors)}"
                    )
                )
        self.out(self.theme.cyan("-" * 68) + "\n")

    def handle_export(self) -> None:
        choice = prompt_choice(
            "Choose Export Format",
            [
                "All Formats (Markdown + Audit TXT + CSV + HTML Chart)",
                "Markdown Executive Report (.md)",
                "Plain-Text Audit Log Report (.txt)",
                "Standardized CSV Analytics Report (.csv)",
                "Visual HTML/SVG Analytics Dashboard (.html)",
            ],
            default="All Formats (Markdown + Audit TXT + CSV + HTML Chart)",
            input_fn=self.input_fn,
            output_fn=self.output_fn,
        )
        summary = self.engine.generate_summary()
        contacts = self.engine.contacts

        if choice.startswith("All Formats"):
            paths = self.exporter.export_all(contacts, summary)
            self.out(self.theme.green("\n  [Exported All Reports]"))
            for kind, path in paths.items():
                self.out(f"    - {kind:<10}: {path}")
        elif choice.startswith("Markdown"):
            path = self.exporter.export_markdown(contacts, summary)
            self.out(self.theme.green(f"\n  [Exported] {path}"))
        elif choice.startswith("Plain-Text"):
            path = self.exporter.export_audit_text(contacts, summary)
            self.out(self.theme.green(f"\n  [Exported] {path}"))
        elif choice.startswith("Standardized CSV"):
            path = self.exporter.export_csv_report(contacts)
            self.out(self.theme.green(f"\n  [Exported] {path}"))
        else:
            path = self.exporter.export_visual_chart_html(summary)
            self.out(self.theme.green(f"\n  [Exported] {path}"))
        self.out()

    def handle_launch_gui(self) -> None:
        self.out(self.theme.cyan("\n  Launching Tkinter Graphical Interface..."))
        try:
            from .gui import launch_gui

            launch_gui(self.engine, self.exporter)
        except Exception as exc:
            self.out(
                self.theme.red(
                    f"  [GUI Unavailable] Could not start Tkinter window: {exc}\n"
                )
            )

    def handle_view_audit_log(self) -> None:
        lines = self.engine.storage.read_audit_log(limit=25)
        self.out("\n" + self.theme.bold("RECENT AUDIT LOG (last 25 entries)"))
        self.out("-" * 78)
        if not lines:
            self.out("  (Audit log is currently empty.)")
        else:
            for line in lines:
                self.out(f"  {line}")
        self.out("-" * 78 + "\n")
