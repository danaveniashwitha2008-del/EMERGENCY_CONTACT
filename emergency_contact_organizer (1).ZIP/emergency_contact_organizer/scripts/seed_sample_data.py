﻿"""One-off dataset builder for Emergency Contact Organizer (42 realistic records)."""

from pathlib import Path
import sys

PROJECT_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_DIR))

from emergency_organizer.storage import ContactStorage
from emergency_organizer.validation import validate_contact_payload

RAW_RECORDS = [
    # 1-10: Critical & Campus Security / Law Enforcement / Fire / Medical
    ("ECO-001", "National Emergency Dispatch", "Public Safety Dispatch", "Law Enforcement", "911", "112", "dispatch@publicsafety.example.org", 1, 3.0, "24/7", "Citywide", "2026-10-15", 90, True, "Active", "Primary municipal emergency dispatch for life-threatening incidents."),
    ("ECO-002", "Campus Police Emergency Desk", "Campus Safety Dept", "Campus Security", "(555) 201-9111", "+1-555-201-9112", "police@campus.example.edu", 1, 2.5, "24/7", "Main Campus", "2026-11-01", 90, True, "Active", "Direct campus police dispatch; dispatches patrol units within 3 mins."),
    ("ECO-003", "University Fire & Rescue Unit", "Campus Fire Marshal", "Fire & Rescue", "+1-555-201-3473", "911", "firemarshal@campus.example.edu", 1, 4.5, "24/7", "Main Campus", "2026-10-20", 90, True, "Active", "Handles fire alarms, lab smoke, and rescue extrication."),
    ("ECO-004", "Mercy General Trauma Center ER", "Mercy Health System", "Medical", "+1-555-310-4000", "+1-555-310-4099", "er-triage@mercyhealth.example.org", 1, 8.0, "24/7", "Downtown / 2km East", "2026-09-25", 120, True, "Active", "Level-1 trauma center; ambulance bay entrance on Oak Ave."),
    ("ECO-005", "988 Suicide & Crisis Lifeline", "National Crisis Network", "Mental Health & Crisis", "988", "+1-800-273-8255", "", 1, 0.0, "24/7", "National Hotline", "2026-11-10", 180, True, "Active", "Immediate zero-wait voice/text crisis counseling (boundary 0.0m ETA)."),
    ("ECO-006", "Poison Control National Center", "American Poison Centers", "Poison & Hazmat", "+1-800-222-1222", "", "info@poisonhelp.example.org", 1, 0.5, "24/7", "National Hotline", "2026-10-05", 180, True, "Active", "24/7 toxicology guidance; lacks alternate phone (info alert demo)."),
    ("ECO-007", "Campus Health Urgent Clinic", "Student Health Services", "Medical", "+1-555-202-4400", "+1-555-202-4401", "urgentcare@campus.example.edu", 2, 6.0, "Academic Hours", "Central Quad", "2026-10-30", 90, True, "Active", "Walk-in acute medical care during academic hours."),
    ("ECO-008", "North Quad Security Booth", "Campus Safety Dept", "Campus Security", "+1-555-201-5501", "+1-555-201-9111", "northgate@campus.example.edu", 2, 4.0, "24/7", "North Campus", "2026-09-01", 120, True, "Active", "24/7 manned guard station near Science & Engineering buildings."),
    ("ECO-009", "Hazmat & Chemical Spill Team", "Environmental Health & Safety", "Poison & Hazmat", "+1-555-204-8800", "+1-555-204-8809", "ehs-hazmat@campus.example.edu", 1, 9.5, "On-Call", "Science Labs", "2026-08-18", 90, True, "Overdue Review", "Critical lab spill containment; verification overdue & On-Call warning."),
    ("ECO-010", "Metro Fire Station #4", "City Fire Department", "Fire & Rescue", "+1-555-322-7700", "911", "station4@cityfire.example.gov", 1, 6.5, "24/7", "West District", "2026-11-12", 180, True, "Active", "Closest municipal ladder & pumper company to dormitories."),

    # 11-20: Mental Health, Utilities, Campus Support, Transport
    ("ECO-011", "Campus Counseling Crisis Line", "Counseling & Psych Services", "Mental Health & Crisis", "+1-555-203-2277", "+1-555-203-2200", "caps@campus.example.edu", 1, 2.0, "24/7", "Campus-Wide", "2026-10-28", 90, True, "Active", "After-hours licensed clinician on call for student distress."),
    ("ECO-012", "Gas Leak Emergency Hotline", "Metro Gas & Power", "Utility & Infrastructure", "+1-800-555-0199", "+1-555-410-1000", "gasemergency@metropower.example.com", 1, 15.0, "24/7", "Citywide", "2026-09-12", 120, True, "Active", "Immediate dispatch for suspected natural gas leaks."),
    ("ECO-013", "Campus Facilities Power & Water", "Facilities Management", "Utility & Infrastructure", "+1-555-205-3000", "+1-555-205-3001", "facilities@campus.example.edu", 2, 18.0, "24/7", "Main Campus", "2026-10-02", 180, True, "Active", "Handles burst pipes, elevator entrapments, and power outages."),
    ("ECO-014", "SafeRide Night Shuttle Dispatch", "Campus Transit Services", "Roadside & Transport", "+1-555-206-7433", "+1-555-206-7400", "saferide@campus.example.edu", 3, 12.0, "Academic Hours", "Campus & 3km Perimeter", "2026-10-10", 180, True, "Active", "Safe evening escort shuttle between labs, library, and housing."),
    ("ECO-015", "Red Cross Disaster Relief Desk", "Regional Red Cross Chapter", "Community Shelter", "+1-555-440-9000", "+1-800-733-2767", "disaster@redcross.example.org", 2, 25.0, "24/7", "Countywide", "2026-07-01", 180, True, "Active", "Emergency shelter setup, cots, and relief supplies."),
    ("ECO-016", "Campus Gym Emergency Shelter", "Student Union Operations", "Community Shelter", "+1-555-207-6100", "+1-555-207-6105", "shelter@campus.example.edu", 3, 20.0, "On-Call", "South Campus", "2026-09-20", 180, True, "Standby", "Designated severe-weather and evacuation assembly shelter."),
    ("ECO-017", "District Police Precinct 2", "Municipal Police Dept", "Law Enforcement", "+1-555-330-2100", "911", "precinct2@citypd.example.gov", 2, 11.0, "24/7", "University District", "2026-11-05", 180, True, "Active", "Local precinct liaison officer for off-campus student housing."),
    ("ECO-018", "Biohazard Waste Response Unit", "Lab Safety & Biohazard", "Poison & Hazmat", "+1-555-204-8950", "+1-555-204-8800", "biosafety@campus.example.edu", 2, 14.0, "Business Hours", "Medical Research Wing", "2026-03-15", 180, True, "Overdue Review", "Exceeds 10m SLA & overdue verification (edge test case)."),
    ("ECO-019", "Regional Ambulance EMS Base", "County EMS Authority", "Medical", "+1-555-315-9900", "911", "ems-ops@countyems.example.gov", 1, 7.0, "24/7", "Citywide", "2026-11-18", 90, True, "Active", "Advanced life support paramedic unit stationed 1.2 km away."),
    ("ECO-020", "Dean on Call (Student Crisis)", "Office of Student Affairs", "Campus Security", "+1-555-208-1100", "+1-555-208-1101", "deanoncall@campus.example.edu", 2, 15.0, "24/7", "Campus-Wide", "2026-10-08", 90, True, "Active", "Coordinates emergency family notification and housing relocation."),

    # 21-30: Family/Personal, IT/Infra, Transport, Community
    ("ECO-021", "Dr. Maya Nair (Primary Physician)", "Campus Faculty Clinic", "Family & Personal", "+1-555-612-3344", "+1-555-612-3345", "mnair@clinic.example.org", 3, 30.0, "Business Hours", "Westside Medical Plaza", "2026-09-14", 365, True, "Active", "Personal physician with allergy & prescription records."),
    ("ECO-022", "Rohan Verma (Emergency Contact)", "Family Guardian", "Family & Personal", "+1-555-781-0042", "+1-555-781-0043", "rohan.verma@family.example.net", 2, 18.0, "24/7", "Local Residence", "2026-11-02", 365, True, "Active", "Primary family ICE contact; carries spare apartment key."),
    ("ECO-023", "Priya Sharma (Next of Kin)", "Family Guardian", "Family & Personal", "+91-98110-55432", "", "priya.s@family.example.net", 3, 45.0, "24/7", "International / Remote", "2026-10-12", 365, True, "Active", "International phone format test case; remote next of kin."),
    ("ECO-024", "Campus Cyber & Alert Operations", "IT Security Operations", "Utility & Infrastructure", "+1-555-209-4357", "+1-555-209-4358", "soc@campus.example.edu", 2, 10.0, "24/7", "Data Center / Campus", "2026-11-20", 90, True, "Active", "Manages mass SMS emergency alerts and network outages."),
    ("ECO-025", "State Highway Patrol Dispatch", "State Troopers", "Roadside & Transport", "+1-800-555-7287", "911", "", 2, 16.0, "24/7", "Interstate Corridor", "2026-08-25", 180, True, "Active", "Highway collision and stranded motorist response."),
    ("ECO-026", "AAA Campus Roadside Assistance", "Auto Club Dispatch", "Roadside & Transport", "+1-800-222-4357", "+1-555-490-2200", "roadside@autoclub.example.com", 4, 35.0, "24/7", "Metro Area", "2026-06-20", 180, True, "Active", "Towing, lockout, and battery jump-start support."),
    ("ECO-027", "Sexual Assault Response Advocate", "Campus Wellness Center", "Mental Health & Crisis", "+1-555-203-7273", "+1-800-656-4673", "advocate@campus.example.edu", 1, 3.0, "24/7", "Campus-Wide", "2026-11-15", 90, True, "Active", "Confidential 24/7 survivor advocacy and hospital accompaniment."),
    ("ECO-028", "City Water Main Emergency", "Municipal Water Utility", "Utility & Infrastructure", "+1-555-412-8800", "+1-555-412-8801", "waterops@cityutil.example.gov", 3, 35.0, "24/7", "Citywide", "2026-09-30", 180, True, "Active", "Shutoff crews for main breaks and flood mitigation."),
    ("ECO-029", "South Dorms Resident Director", "Housing & Residence Life", "Campus Security", "+1-555-208-7700", "+1-555-208-7701", "southra@campus.example.edu", 2, 5.0, "On-Call", "South Residence Halls", "2026-10-19", 90, True, "Active", "Master key access and resident welfare checks."),
    ("ECO-030", "West Valley Dental Emergency", "Valley Dental Associates", "Medical", "+1-555-644-2100", "", "emergency@valleydental.example.com", 4, 45.0, "Weekends Only", "West Valley", "2026-07-18", 180, False, "Standby", "Weekend dental trauma clinic (non-trusted, SLA breach test)."),

    # 31-42: Boundary Values, Edge Cases, Historical & Specialized Contacts
    ("ECO-031", "St. Jude Pediatric Urgent Care", "St. Jude Community Clinic", "Medical", "+1-555-318-7700", "+1-555-318-7705", "peds@stjude.example.org", 2, 12.0, "24/7", "East District", "2026-10-22", 120, True, "Active", "24/7 pediatric emergency walk-in and stabilization."),
    ("ECO-032", "Disaster Recovery Command Post", "County Emergency Mgmt", "Community Shelter", "+1-555-450-1000", "+1-555-450-1001", "eoc@county.example.gov", 2, 28.0, "On-Call", "County EOC", "2026-09-05", 180, True, "Active", "Coordinates multi-agency flood, storm, and evacuation shelters."),
    ("ECO-033", "Campus Elevator Rescue Tech", "Otis Campus Service", "Utility & Infrastructure", "+1-555-205-9090", "+1-555-205-3000", "elevators@campus.example.edu", 2, 22.0, "24/7", "Main Campus", "2026-11-08", 90, True, "Active", "Certified entrapment extraction technician for campus lifts."),
    ("ECO-034", "Transit Rail Safety Control", "Metro Transit Authority", "Roadside & Transport", "+1-555-480-6600", "+1-555-480-6601", "railsafety@metro.example.gov", 3, 18.0, "24/7", "Campus Light Rail", "2026-10-01", 180, True, "Active", "Platform emergencies and grade-crossing incidents."),
    ("ECO-035", "Wildfire & Smoke Air Advisory", "Regional Forestry Fire", "Fire & Rescue", "+1-555-329-5500", "911", "wildfire@forestry.example.gov", 2, 20.0, "24/7", "Foothills Perimeter", "2026-04-01", 180, True, "Overdue Review", "Overdue verification + 20m Fire SLA breach test case."),
    ("ECO-036", "A2", "Short-Name Boundary Unit", "Family & Personal", "+1-555-900-0001", "", "", 5, 1440.0, "Weekends Only", "Z1", "2025-12-01", 730, False, "Standby", "Boundary test: 2-char name/zone, P5, 1440m ETA, 730d interval."),
    ("ECO-037", "Legacy Annex Guard Post", "Campus Safety Dept", "Campus Security", "+1-555-201-5599", "", "annex@campus.example.edu", 4, 15.0, "Business Hours", "Old Annex (Closed)", "2024-11-15", 90, True, "Inactive", "Anomaly test: Inactive status yet marked Trusted, overdue since 2025."),
    ("ECO-038", "Substance Abuse Helpline", "SAMHSA National Helpline", "Mental Health & Crisis", "+1-800-662-4357", "+1-800-487-4889", "", 3, 1.0, "24/7", "National Hotline", "2026-10-29", 365, True, "Active", "Free confidential treatment referral and crisis support."),
    ("ECO-039", "Campus Escort Desk Mirror", "Campus Safety Dept", "Campus Security", "(555) 201-9111", "", "escort@campus.example.edu", 3, 6.0, "Academic Hours", "Library Plaza", "2026-11-04", 180, True, "Active", "Duplicate primary phone test case matching ECO-002."),
    ("ECO-040", "Community Food & Warming Hub", "Neighborhood Mutual Aid", "Community Shelter", "+1-555-445-3200", "+1-555-445-3201", "hub@mutualaid.example.org", 4, 30.0, "Business Hours", "Eastside Community Hall", "2026-09-28", 180, True, "Active", "Winter warming center and emergency meal distribution."),
    ("ECO-041", "Radiological Safety Officer", "Nuclear & Isotope Lab", "Poison & Hazmat", "+1-555-204-9100", "+1-555-204-9101", "rso@campus.example.edu", 1, 7.5, "24/7", "Research Reactor Bldg", "2026-11-19", 30, True, "Active", "30-day high-frequency verification interval boundary test."),
    ("ECO-042", "International Student SOS Desk", "Global Education Office", "Law Enforcement", "+44 20 7946 0958", "+1-555-208-9900", "globalsos@campus.example.edu", 2, 11.5, "24/7", "Global / Travel Desk", "2026-10-25", 90, True, "Active", "24/7 consular and study-abroad emergency coordination."),
]

contacts = []
for row in RAW_RECORDS:
    payload = {
        "contact_id": row[0],
        "full_name": row[1],
        "organization": row[2],
        "category": row[3],
        "phone": row[4],
        "alternate_phone": row[5],
        "email": row[6],
        "priority_level": row[7],
        "response_time_mins": row[8],
        "availability": row[9],
        "location_zone": row[10],
        "last_verified_date": row[11],
        "verification_interval_days": row[12],
        "is_trusted": row[13],
        "status": row[14],
        "notes": row[15],
    }
    contacts.append(validate_contact_payload(payload, require_id=True))

# Write seeded active storage
storage = ContactStorage(data_dir=PROJECT_DIR / "data", logs_dir=PROJECT_DIR / "logs")
storage.save_contacts(contacts, log_event=True)

# Write pristine sample dataset copies
sample_storage = ContactStorage(data_dir=PROJECT_DIR / "data", logs_dir=PROJECT_DIR / "logs")
sample_storage._write_json(PROJECT_DIR / "data" / "sample_contacts.json", contacts)
sample_storage._write_csv(PROJECT_DIR / "data" / "sample_contacts.csv", contacts)

# Write legacy import sample CSV containing valid + invalid + duplicate rows
legacy_csv = """id,name,org,cat,tel,alt_phone,email,priority,eta_mins,availability,zone,last_verified,review_days,trusted,status,notes
ECO-090,Campus Drone Search Team,Search & Rescue Volunteers,Fire & Rescue,+1-555-888-1001,+1-555-888-1002,drone@rescue.example.org,2,9.0,On-Call,North Ridge,2026-11-12,90,yes,Active,Valid legacy row #1
ECO-091,Harbor Coast Guard Liaison,Coast Guard Auxiliary,Law Enforcement,+1-555-888-2001,,liaison@coastguard.example.gov,1,8.5,24/7,Waterfront,2026-11-01,180,true,Active,Valid legacy row #2
ECO-001,Duplicate ID Test,Duplicate Org,Law Enforcement,911,,,1,3.0,24/7,Citywide,2026-10-15,90,true,Active,Should be skipped as duplicate ID
,X,Missing Too Short Name,Medical,12,,,9,9999,InvalidHours,Z,2099-01-01,0,maybe,BogusStatus,Multiple validation errors for row-by-row error log demo
ECO-093,Bad Email & Same Alt Phone,Utility Crew,Utility & Infrastructure,+1-555-777-3001,+1-555-777-3001,not-an-email,3,15,24/7,South Zone,2026-10-01,180,yes,Active,Duplicate alt phone + bad email
"""
(PROJECT_DIR / "data" / "legacy_import_sample.csv").write_text(legacy_csv, encoding="utf-8")
print(f"Generated {len(contacts)} validated contacts and legacy import sample.")

