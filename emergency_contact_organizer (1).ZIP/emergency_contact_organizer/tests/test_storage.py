"""Tests for JSON/CSV persistence, corruption recovery, and audit logging."""

from pathlib import Path
import tempfile
import unittest

from emergency_organizer.storage import ContactStorage
from emergency_organizer.validation import validate_contact_payload


class TestStorage(unittest.TestCase):
    def test_missing_files_initialize_clean_templates(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            storage = ContactStorage(
                data_dir=Path(tmp) / "data", logs_dir=Path(tmp) / "logs"
            )
            contacts, warnings = storage.load_contacts()
            self.assertEqual(contacts, [])
            self.assertTrue(storage.json_path.exists())
            self.assertTrue(storage.csv_path.exists())
            self.assertTrue(any("Created clean initial" in w for w in warnings))

    def test_corrupted_json_recovers_from_csv_and_backs_up(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            data_dir = Path(tmp) / "data"
            logs_dir = Path(tmp) / "logs"
            storage = ContactStorage(data_dir=data_dir, logs_dir=logs_dir)

            sample = validate_contact_payload(
                {
                    "contact_id": "ECO-001",
                    "full_name": "Campus Dispatch",
                    "organization": "Campus Safety",
                    "category": "Campus Security",
                    "phone": "911",
                }
            )
            storage.save_contacts([sample])

            # Corrupt JSON file while CSV remains intact
            storage.json_path.write_text("{broken json!!!", encoding="utf-8")

            recovered, warnings = storage.load_contacts()
            self.assertEqual(len(recovered), 1)
            self.assertEqual(recovered[0].contact_id, "ECO-001")
            self.assertTrue(any("CSV fallback" in w for w in warnings))
            backups = list(data_dir.glob("contacts.json.corrupt.*"))
            self.assertEqual(len(backups), 1)

    def test_corrupted_both_creates_clean_template(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            data_dir = Path(tmp) / "data"
            logs_dir = Path(tmp) / "logs"
            storage = ContactStorage(data_dir=data_dir, logs_dir=logs_dir)
            storage.json_path.write_text("not json", encoding="utf-8")
            storage.csv_path.write_text("", encoding="utf-8")

            contacts, warnings = storage.load_contacts()
            self.assertEqual(contacts, [])
            self.assertTrue(any("clean empty" in w.lower() for w in warnings))


if __name__ == "__main__":
    unittest.main()
