"""Tests for defensive input validation, sanitization, and prompt wrappers."""

from datetime import date, timedelta
import unittest

from emergency_organizer.validation import (
    InputCancelled,
    ValidationError,
    prompt_validated,
    sanitize_csv_cell,
    validate_category,
    validate_contact_payload,
    validate_date_iso,
    validate_email,
    validate_phone,
    validate_priority,
    validate_response_time,
)


class TestValidation(unittest.TestCase):
    def test_valid_payload_roundtrip(self) -> None:
        contact = validate_contact_payload(
            {
                "contact_id": "ECO-101",
                "full_name": "Campus Fire Station #2",
                "organization": "Campus Fire Dept",
                "category": "fire & rescue",
                "phone": "(555) 200-9110",
                "alternate_phone": "911",
                "email": "Fire@Campus.EDU",
                "priority_level": "1",
                "response_time_mins": "4.5",
                "availability": "24/7",
                "location_zone": "North Quad",
                "last_verified_date": date.today().isoformat(),
                "verification_interval_days": 90,
                "is_trusted": "yes",
                "status": "Active",
                "notes": "Main hydrant access",
            }
        )
        self.assertEqual(contact.category, "Fire & Rescue")
        self.assertEqual(contact.email, "fire@campus.edu")
        self.assertEqual(contact.priority_level, 1)
        self.assertEqual(contact.response_time_mins, 4.5)
        self.assertTrue(contact.is_trusted)

    def test_rejects_out_of_range_and_malformed_fields(self) -> None:
        future_date = (date.today() + timedelta(days=5)).isoformat()
        with self.assertRaises(ValidationError) as ctx:
            validate_contact_payload(
                {
                    "contact_id": "BAD",
                    "full_name": "X",
                    "organization": "",
                    "category": "Alien Invasion",
                    "phone": "12",
                    "alternate_phone": "12",
                    "email": "invalid-email",
                    "priority_level": 9,
                    "response_time_mins": -5,
                    "availability": "Never",
                    "location_zone": "A",
                    "last_verified_date": future_date,
                    "verification_interval_days": 0,
                    "is_trusted": "maybe",
                    "status": "Unknown",
                }
            )
        joined = " ".join(ctx.exception.errors)
        self.assertIn("Contact ID", joined)
        self.assertIn("category", joined)
        self.assertIn("priority_level", joined)
        self.assertIn("response_time_mins", joined)
        self.assertIn("last_verified_date", joined)

    def test_phone_and_email_edges(self) -> None:
        self.assertEqual(validate_phone("911"), "911")
        self.assertEqual(validate_email("N/A"), "")
        with self.assertRaises(ValueError):
            validate_phone("abc-def-ghij")
        with self.assertRaises(ValueError):
            validate_priority(True)
        with self.assertRaises(ValueError):
            validate_response_time("nan")
        with self.assertRaises(ValueError):
            validate_category("Unknown")
        self.assertEqual(validate_date_iso("2026-01-15"), "2026-01-15")

    def test_csv_formula_guard(self) -> None:
        self.assertEqual(sanitize_csv_cell("=CMD()"), "'=CMD()")
        self.assertEqual(sanitize_csv_cell("+1-555-0100"), "+1-555-0100")

    def test_prompt_validated_loops_until_valid(self) -> None:
        answers = iter(["", "abc", "9", "2"])
        errors: list[str] = []
        result = prompt_validated(
            "Priority",
            validate_priority,
            input_fn=lambda _: next(answers),
            output_fn=errors.append,
        )
        self.assertEqual(result, 2)
        self.assertEqual(len(errors), 3)

    def test_prompt_validated_cancel(self) -> None:
        with self.assertRaises(InputCancelled):
            prompt_validated(
                "Priority",
                validate_priority,
                input_fn=lambda _: "cancel",
                output_fn=lambda _: None,
            )


if __name__ == "__main__":
    unittest.main()
