"""Lightweight Tkinter Graphical Interface for Emergency Contact Organizer."""

from __future__ import annotations

from datetime import date
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from . import __app_name__, __project_id__, __version__
from .engine import EmergencyContactEngine
from .exporter import SummaryExporter
from .models import (
    VALID_AVAILABILITIES,
    VALID_CATEGORIES,
    VALID_STATUSES,
    EmergencyContact,
)
from .validation import ValidationError


class ContactDialog(tk.Toplevel):
    """Modal dialog to add or edit an emergency contact with validation."""

    def __init__(
        self,
        parent: tk.Misc,
        engine: EmergencyContactEngine,
        contact: EmergencyContact | None = None,
    ) -> None:
        super().__init__(parent)
        self.engine = engine
        self.contact = contact
        self.saved_contact: EmergencyContact | None = None

        self.title(
            f"Edit Contact {contact.contact_id}" if contact else "Add Emergency Contact"
        )
        self.geometry("500x580")
        self.resizable(False, False)
        self.transient(parent)
        self.grab_set()

        frame = ttk.Frame(self, padding=16)
        frame.pack(fill=tk.BOTH, expand=True)

        self.vars: dict[str, tk.Variable] = {
            "full_name": tk.StringVar(value=contact.full_name if contact else ""),
            "organization": tk.StringVar(value=contact.organization if contact else ""),
            "category": tk.StringVar(
                value=contact.category if contact else VALID_CATEGORIES[0]
            ),
            "phone": tk.StringVar(value=contact.phone if contact else ""),
            "alternate_phone": tk.StringVar(
                value=contact.alternate_phone if contact else ""
            ),
            "email": tk.StringVar(value=contact.email if contact else ""),
            "priority_level": tk.StringVar(
                value=str(contact.priority_level) if contact else "2"
            ),
            "response_time_mins": tk.StringVar(
                value=str(contact.response_time_mins) if contact else "10.0"
            ),
            "availability": tk.StringVar(
                value=contact.availability if contact else "24/7"
            ),
            "location_zone": tk.StringVar(
                value=contact.location_zone if contact else "Campus-Wide"
            ),
            "last_verified_date": tk.StringVar(
                value=contact.last_verified_date if contact else date.today().isoformat()
            ),
            "verification_interval_days": tk.StringVar(
                value=str(contact.verification_interval_days) if contact else "180"
            ),
            "status": tk.StringVar(value=contact.status if contact else "Active"),
            "is_trusted": tk.BooleanVar(value=contact.is_trusted if contact else True),
            "notes": tk.StringVar(value=contact.notes if contact else ""),
        }

        rows = [
            ("Full Name *", "full_name", "entry", None),
            ("Organization *", "organization", "entry", None),
            ("Category *", "category", "combo", VALID_CATEGORIES),
            ("Primary Phone *", "phone", "entry", None),
            ("Alternate Phone", "alternate_phone", "entry", None),
            ("Email", "email", "entry", None),
            ("Priority (1-5) *", "priority_level", "combo", ("1", "2", "3", "4", "5")),
            ("Response Time (mins) *", "response_time_mins", "entry", None),
            ("Availability *", "availability", "combo", VALID_AVAILABILITIES),
            ("Location / Zone *", "location_zone", "entry", None),
            ("Last Verified (YYYY-MM-DD)", "last_verified_date", "entry", None),
            ("Review Interval (days)", "verification_interval_days", "entry", None),
            ("Status *", "status", "combo", VALID_STATUSES),
            ("Notes", "notes", "entry", None),
        ]

        for row_idx, (label, key, kind, values) in enumerate(rows):
            ttk.Label(frame, text=label).grid(
                row=row_idx, column=0, sticky=tk.W, pady=4, padx=(0, 8)
            )
            if kind == "combo" and values is not None:
                widget = ttk.Combobox(
                    frame,
                    textvariable=self.vars[key],
                    values=list(values),
                    state="readonly",
                    width=34,
                )
            else:
                widget = ttk.Entry(frame, textvariable=self.vars[key], width=37)
            widget.grid(row=row_idx, column=1, sticky=tk.EW, pady=4)

        ttk.Checkbutton(
            frame,
            text="Trusted Emergency Contact",
            variable=self.vars["is_trusted"],
        ).grid(row=len(rows), column=1, sticky=tk.W, pady=6)

        btn_frame = ttk.Frame(frame)
        btn_frame.grid(row=len(rows) + 1, column=0, columnspan=2, pady=12)
        ttk.Button(btn_frame, text="Save Contact", command=self._on_save).pack(
            side=tk.LEFT, padx=6
        )
        ttk.Button(btn_frame, text="Cancel", command=self.destroy).pack(
            side=tk.LEFT, padx=6
        )

    def _on_save(self) -> None:
        payload = {key: var.get() for key, var in self.vars.items()}
        try:
            if self.contact:
                self.saved_contact = self.engine.update_contact(
                    self.contact.contact_id, payload
                )
            else:
                self.saved_contact = self.engine.add_contact(payload)
            self.destroy()
        except ValidationError as exc:
            messagebox.showerror(
                "Validation Error", "\n".join(exc.errors), parent=self
            )


class EmergencyGUI(tk.Tk):
    """Main Tkinter application window."""

    def __init__(
        self, engine: EmergencyContactEngine, exporter: SummaryExporter
    ) -> None:
        super().__init__()
        self.engine = engine
        self.exporter = exporter
        self.title(f"{__app_name__} v{__version__} — {__project_id__}")
        self.geometry("1120x680")
        self.minsize(940, 560)

        self._build_ui()
        self.refresh_all()

    def _build_ui(self) -> None:
        header = ttk.Frame(self, padding=(14, 10))
        header.pack(fill=tk.X)
        ttk.Label(
            header,
            text=f"{__app_name__}  |  {__project_id__}",
            font=("Segoe UI", 14, "bold"),
        ).pack(side=tk.LEFT)

        self.kpi_label = ttk.Label(header, text="", font=("Segoe UI", 10))
        self.kpi_label.pack(side=tk.RIGHT)

        notebook = ttk.Notebook(self)
        notebook.pack(fill=tk.BOTH, expand=True, padx=12, pady=(0, 12))

        self.tab_contacts = ttk.Frame(notebook, padding=10)
        self.tab_analytics = ttk.Frame(notebook, padding=10)
        self.tab_alerts = ttk.Frame(notebook, padding=10)

        notebook.add(self.tab_contacts, text="Directory & Search")
        notebook.add(self.tab_analytics, text="Executive Summary & Charts")
        notebook.add(self.tab_alerts, text="Threshold Warnings & Audit")

        self._build_contacts_tab()
        self._build_analytics_tab()
        self._build_alerts_tab()

    def _build_contacts_tab(self) -> None:
        controls = ttk.Frame(self.tab_contacts)
        controls.pack(fill=tk.X, pady=(0, 8))

        ttk.Label(controls, text="Search:").pack(side=tk.LEFT)
        self.search_var = tk.StringVar()
        self.search_var.trace_add("write", lambda *_: self._refresh_table())
        ttk.Entry(controls, textvariable=self.search_var, width=28).pack(
            side=tk.LEFT, padx=(4, 12)
        )

        ttk.Label(controls, text="Category:").pack(side=tk.LEFT)
        self.cat_filter_var = tk.StringVar(value="All")
        cat_box = ttk.Combobox(
            controls,
            textvariable=self.cat_filter_var,
            values=["All", *VALID_CATEGORIES],
            state="readonly",
            width=22,
        )
        cat_box.pack(side=tk.LEFT, padx=(4, 12))
        cat_box.bind("<<ComboboxSelected>>", lambda *_: self._refresh_table())

        ttk.Label(controls, text="Status:").pack(side=tk.LEFT)
        self.status_filter_var = tk.StringVar(value="All")
        status_box = ttk.Combobox(
            controls,
            textvariable=self.status_filter_var,
            values=["All", *VALID_STATUSES],
            state="readonly",
            width=15,
        )
        status_box.pack(side=tk.LEFT, padx=(4, 12))
        status_box.bind("<<ComboboxSelected>>", lambda *_: self._refresh_table())

        ttk.Button(controls, text="+ Add", command=self._add_contact).pack(
            side=tk.RIGHT, padx=3
        )
        ttk.Button(controls, text="Edit", command=self._edit_selected).pack(
            side=tk.RIGHT, padx=3
        )
        ttk.Button(controls, text="Verify Today", command=self._verify_selected).pack(
            side=tk.RIGHT, padx=3
        )
        ttk.Button(controls, text="Delete", command=self._delete_selected).pack(
            side=tk.RIGHT, padx=3
        )

        cols = (
            "id",
            "name",
            "category",
            "phone",
            "priority",
            "eta",
            "availability",
            "status",
            "readiness",
        )
        self.tree = ttk.Treeview(
            self.tab_contacts, columns=cols, show="headings", selectmode="browse"
        )
        headings = {
            "id": ("ID", 75),
            "name": ("Name / Service", 210),
            "category": ("Category", 160),
            "phone": ("Phone", 130),
            "priority": ("Priority", 65),
            "eta": ("ETA (m)", 70),
            "availability": ("Availability", 110),
            "status": ("Status", 115),
            "readiness": ("Readiness", 80),
        }
        for col, (title, width) in headings.items():
            self.tree.heading(col, text=title)
            self.tree.column(col, width=width, anchor=tk.W)

        scrollbar = ttk.Scrollbar(
            self.tab_contacts, orient=tk.VERTICAL, command=self.tree.yview
        )
        self.tree.configure(yscrollcommand=scrollbar.set)
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    def _build_analytics_tab(self) -> None:
        top_btns = ttk.Frame(self.tab_analytics)
        top_btns.pack(fill=tk.X, pady=(0, 8))
        ttk.Button(
            top_btns,
            text="Export All Reports (MD / TXT / CSV / HTML)",
            command=self._export_all,
        ).pack(side=tk.LEFT)
        ttk.Button(top_btns, text="Refresh Analytics", command=self.refresh_all).pack(
            side=tk.RIGHT
        )

        self.summary_text = tk.Text(
            self.tab_analytics, height=11, font=("Consolas", 10), state=tk.DISABLED
        )
        self.summary_text.pack(fill=tk.X, pady=(0, 10))

        self.chart_canvas = tk.Canvas(
            self.tab_analytics, bg="#0f172a", height=320, highlightthickness=0
        )
        self.chart_canvas.pack(fill=tk.BOTH, expand=True)

    def _build_alerts_tab(self) -> None:
        actions = ttk.Frame(self.tab_alerts)
        actions.pack(fill=tk.X, pady=(0, 8))
        ttk.Button(actions, text="Bulk Import CSV...", command=self._import_csv).pack(
            side=tk.LEFT
        )
        ttk.Button(actions, text="Refresh Alerts", command=self.refresh_all).pack(
            side=tk.RIGHT
        )

        self.alerts_text = tk.Text(
            self.tab_alerts, font=("Consolas", 10), state=tk.DISABLED
        )
        self.alerts_text.pack(fill=tk.BOTH, expand=True)

    def refresh_all(self) -> None:
        self._refresh_table()
        self._refresh_analytics()
        self._refresh_alerts()

    def _refresh_table(self) -> None:
        for item in self.tree.get_children():
            self.tree.delete(item)
        cat = self.cat_filter_var.get()
        status = self.status_filter_var.get()
        results = self.engine.search_contacts(
            keyword=self.search_var.get(),
            category="" if cat == "All" else cat,
            status="" if status == "All" else status,
        )
        for c in results:
            self.tree.insert(
                "",
                tk.END,
                iid=c.contact_id,
                values=(
                    c.contact_id,
                    c.full_name,
                    c.category,
                    c.phone,
                    f"P{c.priority_level}",
                    f"{c.response_time_mins:.1f}",
                    c.availability,
                    c.status,
                    f"{c.readiness_score():.1f}%",
                ),
            )

    def _refresh_analytics(self) -> None:
        summary = self.engine.generate_summary()
        self.kpi_label.config(
            text=(
                f"Contacts: {summary.total_contacts}  |  Active: {summary.active_count}  |  "
                f"Avg Readiness: {summary.avg_readiness_score:.1f}%  |  "
                f"Alerts: {len(summary.alerts)}"
            )
        )
        lines = [
            f"Total Contacts         : {summary.total_contacts} "
            f"(Active: {summary.active_count}, Standby: {summary.standby_count}, "
            f"Overdue: {summary.overdue_status_count}, Inactive: {summary.inactive_count})",
            f"Trusted / 24-7         : {summary.trusted_count} trusted | "
            f"{summary.twenty_four_seven_count} available 24/7",
            f"Response Time (mins)   : Avg {summary.avg_response_time_mins:.2f} | "
            f"Median {summary.median_response_time_mins:.2f} | "
            f"Min {summary.min_response_time_mins:.1f} | Max {summary.max_response_time_mins:.1f}",
            f"Average Readiness      : {summary.avg_readiness_score:.1f} / 100",
            f"Overdue Verifications  : {summary.overdue_verification_count}",
        ]
        self.summary_text.configure(state=tk.NORMAL)
        self.summary_text.delete("1.0", tk.END)
        self.summary_text.insert("1.0", "\n".join(lines))
        self.summary_text.configure(state=tk.DISABLED)

        self.chart_canvas.delete("all")
        if not summary.category_counts:
            return
        max_cnt = max(summary.category_counts.values(), default=1)
        y = 20
        for cat, cnt in summary.category_counts.items():
            bar_w = int((cnt / max_cnt) * 420)
            avg_eta = summary.category_avg_response.get(cat, 0.0)
            self.chart_canvas.create_text(
                14, y + 10, anchor=tk.W, text=cat, fill="#e2e8f0", font=("Segoe UI", 10)
            )
            self.chart_canvas.create_rectangle(
                220, y, 220 + bar_w, y + 20, fill="#38bdf8", outline=""
            )
            self.chart_canvas.create_text(
                228 + bar_w,
                y + 10,
                anchor=tk.W,
                text=f"{cnt} ({avg_eta:.1f}m avg)",
                fill="#cbd5e1",
                font=("Segoe UI", 9),
            )
            y += 30

    def _refresh_alerts(self) -> None:
        alerts = self.engine.evaluate_threshold_alerts()
        lines = [f"Active Threshold Warnings ({len(alerts)}):", "-" * 80]
        if not alerts:
            lines.append("All contacts pass threshold and SLA checks.")
        else:
            for a in alerts:
                lines.append(
                    f"[{a.severity:<8}] {a.contact_id} | {a.contact_name:<24} | {a.message}"
                )
        lines.extend(["", "Recent Audit Log:", "-" * 80])
        lines.extend(self.engine.storage.read_audit_log(limit=20))

        self.alerts_text.configure(state=tk.NORMAL)
        self.alerts_text.delete("1.0", tk.END)
        self.alerts_text.insert("1.0", "\n".join(lines))
        self.alerts_text.configure(state=tk.DISABLED)

    def _selected_id(self) -> str | None:
        selection = self.tree.selection()
        return selection[0] if selection else None

    def _add_contact(self) -> None:
        dlg = ContactDialog(self, self.engine)
        self.wait_window(dlg)
        if dlg.saved_contact:
            self.refresh_all()

    def _edit_selected(self) -> None:
        cid = self._selected_id()
        if not cid:
            messagebox.showinfo("Select Contact", "Please select a contact first.")
            return
        contact = self.engine.get_contact(cid)
        if contact:
            dlg = ContactDialog(self, self.engine, contact=contact)
            self.wait_window(dlg)
            if dlg.saved_contact:
                self.refresh_all()

    def _verify_selected(self) -> None:
        cid = self._selected_id()
        if not cid:
            messagebox.showinfo("Select Contact", "Please select a contact first.")
            return
        self.engine.mark_verified(cid)
        self.refresh_all()

    def _delete_selected(self) -> None:
        cid = self._selected_id()
        if not cid:
            messagebox.showinfo("Select Contact", "Please select a contact first.")
            return
        if messagebox.askyesno("Confirm Delete", f"Delete contact {cid}?"):
            self.engine.delete_contact(cid)
            self.refresh_all()

    def _import_csv(self) -> None:
        path = filedialog.askopenfilename(
            title="Select Legacy CSV Dataset",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
        )
        if not path:
            return
        try:
            res = self.engine.import_csv(path, on_duplicate="skip")
            self.refresh_all()
            messagebox.showinfo(
                "Bulk Import Complete",
                f"Imported: {res.imported_count}\n"
                f"Skipped Duplicates: {res.skipped_duplicate_count}\n"
                f"Failed Rows: {res.failed_count}\n"
                f"Error Log: {res.error_log_path or 'None'}",
            )
        except Exception as exc:
            messagebox.showerror("Import Error", str(exc))

    def _export_all(self) -> None:
        summary = self.engine.generate_summary()
        paths = self.exporter.export_all(self.engine.contacts, summary)
        msg = "\n".join(f"{k}: {v}" for k, v in paths.items())
        messagebox.showinfo("Reports Exported", msg)


def launch_gui(
    engine: EmergencyContactEngine, exporter: SummaryExporter
) -> None:
    """Start the Tkinter GUI main loop."""
    app = EmergencyGUI(engine, exporter)
    app.mainloop()
