"""Entry point for Emergency Contact Organizer (Project #71 - CampusSolve)."""

from __future__ import annotations

import argparse
from pathlib import Path
import sys

from emergency_organizer import __app_name__, __project_id__, __version__
from emergency_organizer.cli import EmergencyCLI
from emergency_organizer.engine import EmergencyContactEngine
from emergency_organizer.exporter import SummaryExporter
from emergency_organizer.storage import ContactStorage


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    """Parse CLI flags for mode selection and directory overrides."""
    parser = argparse.ArgumentParser(
        description=f"{__app_name__} ({__project_id__}) v{__version__}"
    )
    parser.add_argument(
        "--gui",
        action="store_true",
        help="Launch the optional Tkinter Graphical Interface directly.",
    )
    parser.add_argument(
        "--demo",
        action="store_true",
        help="Run a non-interactive showcase of analytics, alerts, and multi-format export.",
    )
    parser.add_argument(
        "--no-color",
        action="store_true",
        help="Disable ANSI color codes in terminal output.",
    )
    parser.add_argument(
        "--data-dir",
        default="data",
        help="Directory for JSON/CSV storage (default: data).",
    )
    parser.add_argument(
        "--exports-dir",
        default="exports",
        help="Directory for generated reports (default: exports).",
    )
    parser.add_argument(
        "--logs-dir",
        default="logs",
        help="Directory for audit and import error logs (default: logs).",
    )
    return parser.parse_args(argv)


def run_demo_showcase(
    engine: EmergencyContactEngine,
    exporter: SummaryExporter,
    *,
    use_color: bool,
) -> None:
    """Execute a concise automated demo showcase (analytics + alerts + export)."""
    cli = EmergencyCLI(engine, exporter, use_color=use_color)
    cli.render_banner()
    cli.handle_speed_dial()
    cli.handle_summary()
    cli.handle_alerts()
    summary = engine.generate_summary()
    paths = exporter.export_all(engine.contacts, summary)
    print("Exported Demo Reports:")
    for kind, path in paths.items():
        print(f"  - {kind}: {path}")


def main(argv: list[str] | None = None) -> int:
    """Initialize storage, engine, and launch CLI or GUI."""
    args = parse_args(argv)
    base_dir = Path(__file__).resolve().parent

    data_dir = Path(args.data_dir)
    if not data_dir.is_absolute():
        data_dir = base_dir / data_dir

    exports_dir = Path(args.exports_dir)
    if not exports_dir.is_absolute():
        exports_dir = base_dir / exports_dir

    logs_dir = Path(args.logs_dir)
    if not logs_dir.is_absolute():
        logs_dir = base_dir / logs_dir

    storage = ContactStorage(data_dir=data_dir, logs_dir=logs_dir)
    engine = EmergencyContactEngine(storage=storage)
    exporter = SummaryExporter(exports_dir=exports_dir, storage=storage)

    use_color = False if args.no_color else None

    if args.gui:
        from emergency_organizer.gui import launch_gui

        launch_gui(engine, exporter)
        return 0

    if args.demo:
        run_demo_showcase(
            engine, exporter, use_color=False if args.no_color else True
        )
        return 0

    cli = EmergencyCLI(engine, exporter, use_color=use_color)
    cli.run()
    return 0


if __name__ == "__main__":
    sys.exit(main())
