"""Multi-format summary exporter (Markdown, Audit TXT, CSV, HTML/SVG chart)."""

from __future__ import annotations

import csv
from datetime import datetime
import html
from pathlib import Path

from .models import EmergencyContact, PRIORITY_LABELS, SummaryMetrics
from .storage import ContactStorage
from .validation import sanitize_csv_cell


class SummaryExporter:
    """Exports emergency contact reports and analytics in multiple formats."""

    def __init__(
        self,
        exports_dir: str | Path = "exports",
        storage: ContactStorage | None = None,
    ) -> None:
        self.exports_dir = Path(exports_dir)
        self.exports_dir.mkdir(parents=True, exist_ok=True)
        self.storage = storage

    def _timestamp(self) -> str:
        return datetime.now().strftime("%Y%m%d_%H%M%S")

    def export_markdown(
        self,
        contacts: list[EmergencyContact],
        summary: SummaryMetrics,
        *,
        filename: str | None = None,
    ) -> Path:
        """Generate a structured Markdown executive summary and contact report."""
        self.exports_dir.mkdir(parents=True, exist_ok=True)
        out_path = self.exports_dir / (
            filename or f"emergency_summary_{self._timestamp()}.md"
        )
        now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        lines: list[str] = [
            "# Emergency Contact Organizer — Executive Summary Report",
            "",
            f"- **Generated:** {now_str}",
            f"- **Total Contacts:** {summary.total_contacts}",
            f"- **Active / Standby / Overdue / Inactive:** "
            f"{summary.active_count} / {summary.standby_count} / "
            f"{summary.overdue_status_count} / {summary.inactive_count}",
            f"- **Trusted Contacts:** {summary.trusted_count}",
            f"- **24/7 Coverage:** {summary.twenty_four_seven_count}",
            f"- **Average Response Time:** {summary.avg_response_time_mins:.2f} mins "
            f"(Median: {summary.median_response_time_mins:.2f} mins, "
            f"Range: {summary.min_response_time_mins:.1f}–{summary.max_response_time_mins:.1f} mins)",
            f"- **Average Readiness Score:** {summary.avg_readiness_score:.1f} / 100",
            f"- **Overdue Verifications:** {summary.overdue_verification_count}",
            "",
            "## Category Distribution & Avg Response Time",
            "",
            "| Category | Contacts | Avg Response (mins) |",
            "|---|---:|---:|",
        ]

        for cat, count in summary.category_counts.items():
            avg_resp = summary.category_avg_response.get(cat, 0.0)
            lines.append(f"| {cat} | {count} | {avg_resp:.2f} |")

        lines.extend(
            [
                "",
                "## Priority Breakdown",
                "",
                "| Priority | Label | Count |",
                "|---:|---|---:|",
            ]
        )
        for prio, count in summary.priority_counts.items():
            lines.append(
                f"| P{prio} | {PRIORITY_LABELS.get(prio, 'Unknown')} | {count} |"
            )

        lines.extend(["", "## Threshold Warnings & Anomalies", ""])
        if summary.alerts:
            lines.append("| Severity | Code | Contact | Details |")
            lines.append("|---|---|---|---|")
            for alert in summary.alerts:
                lines.append(
                    f"| {alert.severity} | `{alert.code}` | "
                    f"{alert.contact_id} ({alert.contact_name}) | {alert.message} |"
                )
        else:
            lines.append("No threshold warnings or anomalies detected.")

        lines.extend(
            [
                "",
                "## Critical & High-Priority Directory Snapshot",
                "",
                "| ID | Name | Category | Phone | Availability | ETA (m) | Readiness | Status |",
                "|---|---|---|---|---|---:|---:|---|",
            ]
        )
        top_contacts = sorted(
            contacts, key=lambda c: (c.priority_level, c.response_time_mins)
        )[:15]
        for c in top_contacts:
            lines.append(
                f"| {c.contact_id} | {c.full_name} | {c.category} | {c.phone} | "
                f"{c.availability} | {c.response_time_mins:.1f} | "
                f"{c.readiness_score():.1f} | {c.status} |"
            )

        out_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
        if self.storage:
            self.storage.append_audit_log(
                "EXPORT_MD", f"Exported Markdown report to {out_path.name}"
            )
        return out_path

    def export_audit_text(
        self,
        contacts: list[EmergencyContact],
        summary: SummaryMetrics,
        *,
        filename: str | None = None,
    ) -> Path:
        """Generate a plain-text operational audit report + recent activity trail."""
        self.exports_dir.mkdir(parents=True, exist_ok=True)
        out_path = self.exports_dir / (
            filename or f"emergency_audit_{self._timestamp()}.txt"
        )
        now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        sep = "=" * 78

        lines: list[str] = [
            sep,
            "EMERGENCY CONTACT ORGANIZER — AUDIT & COMPLIANCE REPORT",
            f"Generated: {now_str}",
            sep,
            f"Total Records          : {summary.total_contacts}",
            f"Active / Standby       : {summary.active_count} / {summary.standby_count}",
            f"Overdue / Inactive     : {summary.overdue_status_count} / {summary.inactive_count}",
            f"Trusted Coverage       : {summary.trusted_count}",
            f"24/7 Availability      : {summary.twenty_four_seven_count}",
            f"Avg Readiness Score    : {summary.avg_readiness_score:.1f} / 100",
            f"Avg Response Time      : {summary.avg_response_time_mins:.2f} mins",
            f"Avg Days Since Verify  : {summary.avg_days_since_verified:.1f} days",
            "",
            "--- THRESHOLD ALERTS ---",
        ]
        if summary.alerts:
            for alert in summary.alerts:
                lines.append(
                    f"[{alert.severity}] {alert.contact_id} ({alert.contact_name}) "
                    f"[{alert.code}]: {alert.message}"
                )
        else:
            lines.append("No active alerts.")

        lines.extend(["", "--- RECENT SYSTEM AUDIT LOG ---"])
        recent_logs = self.storage.read_audit_log(limit=40) if self.storage else []
        if recent_logs:
            lines.extend(recent_logs)
        else:
            lines.append("No prior audit log events recorded.")

        lines.extend(["", f"--- DIRECTORY CHECKSUM ({len(contacts)} CONTACTS) ---"])
        for c in sorted(contacts, key=lambda item: item.contact_id):
            lines.append(
                f"{c.contact_id} | P{c.priority_level} | {c.status:<14} | "
                f"{c.full_name:<28} | {c.phone:<16} | Verified: {c.last_verified_date}"
            )

        out_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
        if self.storage:
            self.storage.append_audit_log(
                "EXPORT_TXT", f"Exported plain-text audit report to {out_path.name}"
            )
        return out_path

    def export_csv_report(
        self,
        contacts: list[EmergencyContact],
        *,
        filename: str | None = None,
    ) -> Path:
        """Generate a standardized CSV analytics report with computed readiness metrics."""
        self.exports_dir.mkdir(parents=True, exist_ok=True)
        out_path = self.exports_dir / (
            filename or f"emergency_report_{self._timestamp()}.csv"
        )
        fieldnames = [
            "contact_id",
            "full_name",
            "organization",
            "category",
            "phone",
            "alternate_phone",
            "email",
            "priority_level",
            "priority_label",
            "response_time_mins",
            "availability",
            "location_zone",
            "last_verified_date",
            "days_overdue",
            "readiness_score",
            "is_trusted",
            "status",
        ]
        with out_path.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=fieldnames)
            writer.writeheader()
            for c in sorted(
                contacts, key=lambda item: (item.priority_level, item.contact_id)
            ):
                writer.writerow(
                    {
                        "contact_id": c.contact_id,
                        "full_name": sanitize_csv_cell(c.full_name),
                        "organization": sanitize_csv_cell(c.organization),
                        "category": c.category,
                        "phone": c.phone,
                        "alternate_phone": c.alternate_phone,
                        "email": c.email,
                        "priority_level": c.priority_level,
                        "priority_label": c.priority_label(),
                        "response_time_mins": c.response_time_mins,
                        "availability": c.availability,
                        "location_zone": sanitize_csv_cell(c.location_zone),
                        "last_verified_date": c.last_verified_date,
                        "days_overdue": c.days_overdue(),
                        "readiness_score": c.readiness_score(),
                        "is_trusted": c.is_trusted,
                        "status": c.status,
                    }
                )
        if self.storage:
            self.storage.append_audit_log(
                "EXPORT_CSV", f"Exported standardized CSV report to {out_path.name}"
            )
        return out_path

    def export_visual_chart_html(
        self,
        summary: SummaryMetrics,
        *,
        filename: str | None = None,
    ) -> Path:
        """Generate a zero-dependency standalone HTML/SVG visual analytics dashboard."""
        self.exports_dir.mkdir(parents=True, exist_ok=True)
        out_path = self.exports_dir / (
            filename or f"emergency_dashboard_{self._timestamp()}.html"
        )

        max_cat = max(summary.category_counts.values(), default=1)
        bars_svg: list[str] = []
        y = 20
        for cat, count in summary.category_counts.items():
            width = int((count / max_cat) * 340) if max_cat else 0
            avg_eta = summary.category_avg_response.get(cat, 0.0)
            bars_svg.append(
                f'<text x="10" y="{y + 16}" font-size="13" fill="#e2e8f0">{html.escape(cat)}</text>'
                f'<rect x="210" y="{y}" width="{width}" height="22" rx="4" fill="#38bdf8"/>'
                f'<text x="{218 + width}" y="{y + 16}" font-size="12" fill="#cbd5e1">'
                f'{count} ({avg_eta:.1f}m avg)</text>'
            )
            y += 34

        svg_height = max(120, y + 10)
        doc = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Emergency Contact Organizer — Analytics Dashboard</title>
<style>
  body {{ font-family: system-ui, -apple-system, sans-serif; background: #0f172a; color: #f8fafc; margin: 2rem; }}
  .grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 1rem; margin-bottom: 1.5rem; }}
  .card {{ background: #1e293b; border: 1px solid #334155; border-radius: 10px; padding: 1rem; }}
  .label {{ color: #94a3b8; font-size: 0.85rem; }}
  .value {{ font-size: 1.6rem; font-weight: 700; margin-top: 0.25rem; color: #38bdf8; }}
  .panel {{ background: #1e293b; border: 1px solid #334155; border-radius: 10px; padding: 1.25rem; margin-bottom: 1.5rem; }}
  h1, h2 {{ margin-top: 0; }}
</style>
</head>
<body>
  <h1>Emergency Contact Organizer — Analytics Snapshot</h1>
  <p style="color:#94a3b8">Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}</p>
  <div class="grid">
    <div class="card"><div class="label">Total Contacts</div><div class="value">{summary.total_contacts}</div></div>
    <div class="card"><div class="label">Active / 24-7</div><div class="value">{summary.active_count} / {summary.twenty_four_seven_count}</div></div>
    <div class="card"><div class="label">Avg Readiness</div><div class="value">{summary.avg_readiness_score:.1f}%</div></div>
    <div class="card"><div class="label">Avg Response</div><div class="value">{summary.avg_response_time_mins:.1f}m</div></div>
    <div class="card"><div class="label">Active Alerts</div><div class="value" style="color:#f59e0b">{len(summary.alerts)}</div></div>
  </div>
  <div class="panel">
    <h2>Contacts &amp; Avg Response Time by Category</h2>
    <svg width="700" height="{svg_height}" xmlns="http://www.w3.org/2000/svg">
      {"".join(bars_svg)}
    </svg>
  </div>
</body>
</html>
"""
        out_path.write_text(doc, encoding="utf-8")
        if self.storage:
            self.storage.append_audit_log(
                "EXPORT_HTML", f"Exported visual HTML/SVG chart to {out_path.name}"
            )
        return out_path

    def export_matplotlib_chart(
        self, summary: SummaryMetrics, *, filename: str | None = None
    ) -> Path | None:
        """Optionally render a PNG chart if Matplotlib is installed in the environment."""
        try:
            import matplotlib.pyplot as plt  # type: ignore
        except ImportError:
            return None

        self.exports_dir.mkdir(parents=True, exist_ok=True)
        out_path = self.exports_dir / (
            filename or f"emergency_chart_{self._timestamp()}.png"
        )
        categories = list(summary.category_counts.keys())
        counts = list(summary.category_counts.values())
        if not categories:
            return None

        fig, ax = plt.subplots(figsize=(9, 5))
        ax.barh(categories[::-1], counts[::-1], color="#0284c7")
        ax.set_xlabel("Number of Contacts")
        ax.set_title("Emergency Contacts by Category")
        plt.tight_layout()
        fig.savefig(out_path, dpi=140)
        plt.close(fig)
        if self.storage:
            self.storage.append_audit_log(
                "EXPORT_PNG", f"Exported Matplotlib chart to {out_path.name}"
            )
        return out_path

    def export_all(
        self, contacts: list[EmergencyContact], summary: SummaryMetrics
    ) -> dict[str, Path]:
        """Export Markdown, TXT audit, CSV report, HTML chart, and optional PNG."""
        stamp = self._timestamp()
        results: dict[str, Path] = {
            "markdown": self.export_markdown(
                contacts, summary, filename=f"emergency_summary_{stamp}.md"
            ),
            "audit_txt": self.export_audit_text(
                contacts, summary, filename=f"emergency_audit_{stamp}.txt"
            ),
            "csv": self.export_csv_report(
                contacts, filename=f"emergency_report_{stamp}.csv"
            ),
            "html_chart": self.export_visual_chart_html(
                summary, filename=f"emergency_dashboard_{stamp}.html"
            ),
        }
        png_path = self.export_matplotlib_chart(
            summary, filename=f"emergency_chart_{stamp}.png"
        )
        if png_path:
            results["png_chart"] = png_path
        return results
