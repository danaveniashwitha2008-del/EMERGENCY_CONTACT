"""Tests for multi-format summary export (Markdown, Audit TXT, CSV, HTML/SVG)."""

from pathlib import Path
import tempfile
import unittest

from emergency_organizer.engine import EmergencyContactEngine
from emergency_organizer.exporter import SummaryExporter
from emergency_organizer.storage import ContactStorage


class TestExporter(unittest.TestCase):
    def test_export_all_formats(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            storage = ContactStorage(
                data_dir=Path(tmp) / "data", logs_dir=Path(tmp) / "logs"
            )
            engine = EmergencyContactEngine(storage=storage)
            engine.add_contact(
                {
                    "full_name": "Campus Dispatch",
                    "organization": "Campus Safety",
                    "category": "Campus Security",
                    "phone": "+1-555-201-9111",
                    "priority_level": 1,
                    "response_time_mins": 3.0,
                }
            )
            exporter = SummaryExporter(
                exports_dir=Path(tmp) / "exports", storage=storage
            )
            summary = engine.generate_summary()
            paths = exporter.export_all(engine.contacts, summary)

            self.assertTrue(paths["markdown"].exists())
            self.assertTrue(paths["audit_txt"].exists())
            self.assertTrue(paths["csv"].exists())
            self.assertTrue(paths["html_chart"].exists())

            md_text = paths["markdown"].read_text(encoding="utf-8")
            self.assertIn("Executive Summary Report", md_text)
            self.assertIn("Campus Dispatch", md_text)

            html_text = paths["html_chart"].read_text(encoding="utf-8")
            self.assertIn("<svg", html_text)


if __name__ == "__main__":
    unittest.main()
