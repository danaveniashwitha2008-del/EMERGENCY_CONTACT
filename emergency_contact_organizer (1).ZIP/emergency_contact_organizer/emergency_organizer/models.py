"""Core data structures, constants, and domain schemas."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import date, datetime, timedelta
import re
from typing import Any

VALID_CATEGORIES: tuple[str, ...] = (
    "Medical",
    "Fire & Rescue",
    "Law Enforcement",
    "Campus Security",
    "Mental Health & Crisis",
    "Utility & Infrastructure",
    "Poison & Hazmat",
    "Roadside & Transport",
    "Community Shelter",
    "Family & Personal",
)

VALID_AVAILABILITIES: tuple[str, ...] = (
    "24/7",
    "On-Call",
    "Business Hours",
    "Academic Hours",
    "Weekends Only",
)

VALID_STATUSES: tuple[str, ...] = (
    "Active",
    "Standby",
    "Overdue Review",
    "Inactive",
)

PRIORITY_LABELS: dict[int, str] = {
    1: "Critical",
    2: "High",
    3: "Medium",
    4: "Standard",
    5: "Low",
}

CSV_COLUMNS: tuple[str, ...] = (
    "contact_id",
    "full_name",
    "organization",
    "category",
    "phone",
    "alternate_phone",
    "email",
    "priority_level",
    "response_time_mins",
    "availability",
    "location_zone",
    "last_verified_date",
    "verification_interval_days",
    "is_trusted",
    "status",
    "notes",
    "created_at",
    "updated_at",
)

CATEGORY_SLA_MAX_MINS: dict[str, float] = {
    "Medical": 12.0,
    "Fire & Rescue": 10.0,
    "Law Enforcement": 12.0,
    "Campus Security": 8.0,
    "Mental Health & Crisis": 5.0,
    "Poison & Hazmat": 10.0,
    "Utility & Infrastructure": 45.0,
    "Roadside & Transport": 40.0,
    "Community Shelter": 30.0,
    "Family & Personal": 20.0,
}

MIN_PRIORITY = 1
MAX_PRIORITY = 5
MIN_RESPONSE_MINS = 0.0
MAX_RESPONSE_MINS = 1440.0
MIN_VERIFICATION_INTERVAL = 1
MAX_VERIFICATION_INTERVAL = 730


def normalize_phone_digits(phone: str) -> str:
    """Return only numeric digits from a phone string for comparison."""
    return re.sub(r"\D", "", phone or "")


def _parse_bool(value: Any) -> bool:
    """Coerce common boolean representations safely."""
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    text = str(value).strip().lower()
    if text in {"true", "1", "yes", "y", "on"}:
        return True
    if text in {"false", "0", "no", "n", "off", ""}:
        return False
    raise ValueError(f"Invalid boolean value: {value!r}")


@dataclass
class EmergencyContact:
    """Represents a trusted local emergency contact record."""

    contact_id: str
    full_name: str
    organization: str
    category: str
    phone: str
    alternate_phone: str = ""
    email: str = ""
    priority_level: int = 2
    response_time_mins: float = 10.0
    availability: str = "24/7"
    location_zone: str = "Campus-Wide"
    last_verified_date: str = field(default_factory=lambda: date.today().isoformat())
    verification_interval_days: int = 180
    is_trusted: bool = True
    status: str = "Active"
    notes: str = ""
    created_at: str = field(
        default_factory=lambda: datetime.now().isoformat(timespec="seconds")
    )
    updated_at: str = field(
        default_factory=lambda: datetime.now().isoformat(timespec="seconds")
    )

    def normalized_phone(self) -> str:
        """Return digits-only representation of primary phone."""
        return normalize_phone_digits(self.phone)

    def next_review_date(self) -> date:
        """Return the date by which this contact should be re-verified."""
        verified = date.fromisoformat(self.last_verified_date)
        return verified + timedelta(days=self.verification_interval_days)

    def days_since_verified(self, reference_date: date | None = None) -> int:
        """Return whole days elapsed since last_verified_date."""
        ref = reference_date or date.today()
        verified = date.fromisoformat(self.last_verified_date)
        return (ref - verified).days

    def days_overdue(self, reference_date: date | None = None) -> int:
        """Return days past the verification deadline (0 if not overdue)."""
        ref = reference_date or date.today()
        delta = (ref - self.next_review_date()).days
        return max(0, delta)

    def is_verification_overdue(self, reference_date: date | None = None) -> bool:
        """Return True when the verification deadline has passed."""
        return self.days_overdue(reference_date) > 0

    def readiness_score(self, reference_date: date | None = None) -> float:
        """Compute a 0-100 operational readiness score for this contact."""
        score = 40.0
        if self.status == "Active":
            score += 20.0
        elif self.status == "Standby":
            score += 10.0
        elif self.status == "Overdue Review":
            score += 5.0

        if self.is_trusted:
            score += 10.0
        if self.availability == "24/7":
            score += 10.0
        elif self.availability == "On-Call":
            score += 6.0
        else:
            score += 3.0

        if self.alternate_phone:
            score += 5.0

        sla_limit = CATEGORY_SLA_MAX_MINS.get(self.category, 20.0)
        if self.response_time_mins <= sla_limit:
            score += 10.0
        elif self.response_time_mins <= sla_limit * 2:
            score += 5.0

        if not self.is_verification_overdue(reference_date):
            score += 5.0
        else:
            overdue = self.days_overdue(reference_date)
            score -= min(15.0, overdue * 0.1)

        if self.status == "Inactive":
            score = min(score, 25.0)

        return round(max(0.0, min(100.0, score)), 1)

    def priority_label(self) -> str:
        """Return human-readable label for priority_level."""
        return PRIORITY_LABELS.get(self.priority_level, "Unknown")

    def to_dict(self) -> dict[str, Any]:
        """Serialize record to a JSON/CSV-compatible dictionary."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> EmergencyContact:
        """Deserialize a dictionary into an EmergencyContact instance."""
        now_iso = datetime.now().isoformat(timespec="seconds")
        today_iso = date.today().isoformat()
        return cls(
            contact_id=str(data.get("contact_id", "")).strip(),
            full_name=str(data.get("full_name", "")).strip(),
            organization=str(data.get("organization", "")).strip(),
            category=str(data.get("category", "")).strip(),
            phone=str(data.get("phone", "")).strip(),
            alternate_phone=str(data.get("alternate_phone", "") or "").strip(),
            email=str(data.get("email", "") or "").strip(),
            priority_level=int(data["priority_level"]),
            response_time_mins=float(data["response_time_mins"]),
            availability=str(data.get("availability", "24/7")).strip(),
            location_zone=str(data.get("location_zone", "")).strip(),
            last_verified_date=str(
                data.get("last_verified_date") or today_iso
            ).strip(),
            verification_interval_days=int(
                data.get("verification_interval_days", 180)
            ),
            is_trusted=_parse_bool(data.get("is_trusted", True)),
            status=str(data.get("status", "Active")).strip(),
            notes=str(data.get("notes", "") or "").strip(),
            created_at=str(data.get("created_at") or now_iso).strip(),
            updated_at=str(data.get("updated_at") or now_iso).strip(),
        )


@dataclass
class ThresholdAlert:
    """Represents an automated threshold or anomaly warning."""

    severity: str  # "CRITICAL", "WARNING", "INFO"
    code: str
    contact_id: str
    contact_name: str
    message: str


@dataclass
class RowError:
    """Represents a single row validation failure during bulk CSV import."""

    row_number: int
    raw_identifier: str
    errors: list[str]


@dataclass
class ImportResult:
    """Summary of a bulk CSV import operation."""

    source_file: str
    total_rows: int
    imported_count: int
    updated_count: int
    skipped_duplicate_count: int
    failed_count: int
    row_errors: list[RowError] = field(default_factory=list)
    error_log_path: str = ""


@dataclass
class SummaryMetrics:
    """Aggregated executive summary metrics across stored contacts."""

    total_contacts: int
    active_count: int
    standby_count: int
    overdue_status_count: int
    inactive_count: int
    trusted_count: int
    twenty_four_seven_count: int
    overdue_verification_count: int
    critical_priority_count: int
    avg_priority: float
    avg_response_time_mins: float
    median_response_time_mins: float
    min_response_time_mins: float
    max_response_time_mins: float
    avg_readiness_score: float
    avg_days_since_verified: float
    category_counts: dict[str, int]
    category_avg_response: dict[str, float]
    priority_counts: dict[int, int]
    status_counts: dict[str, int]
    availability_counts: dict[str, int]
    monthly_verification_trend: dict[str, int]
    alerts: list[ThresholdAlert]
