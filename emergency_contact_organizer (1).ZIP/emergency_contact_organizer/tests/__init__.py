"""Unit and end-to-end test suite for Emergency Contact Organizer."""
