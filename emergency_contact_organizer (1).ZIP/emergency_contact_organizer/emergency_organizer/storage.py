"""Local JSON/CSV persistence, corruption recovery, and plain-text audit logging."""

from __future__ import annotations

import csv
from datetime import datetime
import json
from pathlib import Path
import shutil
from typing import Any

from .models import CSV_COLUMNS, EmergencyContact
from .validation import ValidationError, sanitize_csv_cell, validate_contact_payload

SCHEMA_VERSION = 1


class ContactStorage:
    """Manages local JSON and CSV persistence with automatic corruption recovery."""

    def __init__(
        self,
        data_dir: str | Path = "data",
        logs_dir: str | Path = "logs",
    ) -> None:
        self.data_dir = Path(data_dir)
        self.logs_dir = Path(logs_dir)
        self.json_path = self.data_dir / "contacts.json"
        self.csv_path = self.data_dir / "contacts.csv"
        self.audit_log_path = self.logs_dir / "audit_log.txt"
        self.ensure_directories()

    def ensure_directories(self) -> None:
        """Create data and logs directories if they do not exist."""
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.logs_dir.mkdir(parents=True, exist_ok=True)

    def append_audit_log(self, action: str, details: str) -> None:
        """Append a timestamped entry to the plain-text audit log."""
        self.ensure_directories()
        timestamp = datetime.now().isoformat(timespec="seconds")
        line = f"[{timestamp}] [{action.upper()}] {details}\n"
        try:
            with self.audit_log_path.open("a", encoding="utf-8") as handle:
                handle.write(line)
        except OSError:
            # Never allow audit logging I/O issues to crash core operations.
            pass

    def read_audit_log(self, limit: int = 50) -> list[str]:
        """Return the most recent audit log lines."""
        if not self.audit_log_path.exists():
            return []
        try:
            lines = self.audit_log_path.read_text(encoding="utf-8").splitlines()
            return lines[-limit:] if limit > 0 else lines
        except OSError:
            return []

    def _backup_corrupt_file(self, path: Path) -> Path | None:
        """Move or copy a corrupted file aside before recreating a clean template."""
        if not path.exists():
            return None
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = path.with_name(f"{path.name}.corrupt.{stamp}")
        try:
            shutil.copy2(path, backup_path)
            return backup_path
        except OSError:
            return None

    def initialize_clean_templates(self) -> None:
        """Create clean empty JSON and CSV storage templates."""
        self.save_contacts([], log_event=False)

    def load_contacts(self) -> tuple[list[EmergencyContact], list[str]]:
        """Load contacts from JSON (with CSV fallback) and return (contacts, warnings)."""
        self.ensure_directories()
        warnings: list[str] = []

        if self.json_path.exists():
            contacts, json_warnings = self._load_from_json(self.json_path)
            warnings.extend(json_warnings)
            if contacts or not json_warnings:
                if not self.csv_path.exists():
                    self._write_csv(self.csv_path, contacts)
                return contacts, warnings

            # JSON was unreadable/corrupted; check if CSV fallback has valid records.
            if self.csv_path.exists():
                csv_contacts, csv_warnings = self._load_from_csv(self.csv_path)
                if csv_contacts:
                    warnings.append(
                        "Recovered contact records from CSV fallback after JSON error."
                    )
                    warnings.extend(csv_warnings)
                    self.save_contacts(csv_contacts, log_event=False)
                    self.append_audit_log(
                        "RECOVERY",
                        f"Recovered {len(csv_contacts)} contacts from CSV fallback.",
                    )
                    return csv_contacts, warnings

            self.initialize_clean_templates()
            warnings.append("Initialized clean empty JSON and CSV storage templates.")
            return [], warnings

        if self.csv_path.exists():
            csv_contacts, csv_warnings = self._load_from_csv(self.csv_path)
            warnings.extend(csv_warnings)
            self._write_json(self.json_path, csv_contacts)
            self.append_audit_log(
                "INIT",
                f"Initialized JSON store from existing CSV ({len(csv_contacts)} contacts).",
            )
            return csv_contacts, warnings

        self.initialize_clean_templates()
        warnings.append(
            "No existing storage files found. Created clean initial JSON and CSV templates."
        )
        self.append_audit_log("INIT", "Created clean initial JSON and CSV templates.")
        return [], warnings

    def _load_from_json(
        self, path: Path
    ) -> tuple[list[EmergencyContact], list[str]]:
        """Read and schema-validate contacts from a JSON file."""
        warnings: list[str] = []
        try:
            raw_text = path.read_text(encoding="utf-8")
            if not raw_text.strip():
                raise json.JSONDecodeError("Empty JSON file", raw_text, 0)
            payload = json.loads(raw_text)
        except (FileNotFoundError, json.JSONDecodeError, UnicodeDecodeError, OSError) as exc:
            backup = self._backup_corrupt_file(path)
            msg = f"Corrupted or unreadable JSON file ({exc})."
            if backup:
                msg += f" Backed up to '{backup.name}'."
            warnings.append(msg)
            self.append_audit_log("RECOVERY", msg)
            return [], warnings

        if isinstance(payload, dict):
            records = payload.get("contacts")
            if not isinstance(records, list):
                backup = self._backup_corrupt_file(path)
                msg = "JSON schema error: missing 'contacts' list."
                if backup:
                    msg += f" Backed up to '{backup.name}'."
                warnings.append(msg)
                self.append_audit_log("RECOVERY", msg)
                return [], warnings
        elif isinstance(payload, list):
            records = payload
        else:
            backup = self._backup_corrupt_file(path)
            msg = "JSON schema error: expected object or array."
            if backup:
                msg += f" Backed up to '{backup.name}'."
            warnings.append(msg)
            self.append_audit_log("RECOVERY", msg)
            return [], warnings

        return self._validate_loaded_records(records, warnings, source="JSON")

    def _load_from_csv(
        self, path: Path
    ) -> tuple[list[EmergencyContact], list[str]]:
        """Read and schema-validate contacts from a CSV file."""
        warnings: list[str] = []
        try:
            with path.open("r", encoding="utf-8-sig", newline="") as handle:
                reader = csv.DictReader(handle)
                if not reader.fieldnames:
                    raise csv.Error("CSV file has no header row.")
                records = list(reader)
        except (FileNotFoundError, csv.Error, UnicodeDecodeError, OSError) as exc:
            backup = self._backup_corrupt_file(path)
            msg = f"Corrupted or unreadable CSV file ({exc})."
            if backup:
                msg += f" Backed up to '{backup.name}'."
            warnings.append(msg)
            self.append_audit_log("RECOVERY", msg)
            return [], warnings

        return self._validate_loaded_records(records, warnings, source="CSV")

    def _validate_loaded_records(
        self,
        records: list[Any],
        warnings: list[str],
        *,
        source: str,
    ) -> tuple[list[EmergencyContact], list[str]]:
        """Validate deserialized record dicts, skipping malformed entries cleanly."""
        contacts: list[EmergencyContact] = []
        seen_ids: set[str] = set()

        for idx, item in enumerate(records, start=1):
            if not isinstance(item, dict):
                warnings.append(f"{source} entry #{idx} skipped: expected object.")
                continue
            try:
                contact = validate_contact_payload(
                    item, require_id=True, allow_future_date=True
                )
            except ValidationError as exc:
                warnings.append(
                    f"{source} entry #{idx} ({item.get('contact_id', 'unknown')}) skipped: {exc}"
                )
                continue

            if contact.contact_id in seen_ids:
                warnings.append(
                    f"{source} entry #{idx} skipped: duplicate contact_id '{contact.contact_id}'."
                )
                continue
            seen_ids.add(contact.contact_id)
            contacts.append(contact)

        return contacts, warnings

    def save_contacts(
        self, contacts: list[EmergencyContact], *, log_event: bool = True
    ) -> None:
        """Persist contacts atomically to both JSON and CSV files."""
        self.ensure_directories()
        self._write_json(self.json_path, contacts)
        self._write_csv(self.csv_path, contacts)
        if log_event:
            self.append_audit_log(
                "SAVE", f"Persisted {len(contacts)} contacts to JSON and CSV."
            )

    def _write_json(self, path: Path, contacts: list[EmergencyContact]) -> None:
        """Write contacts atomically to JSON with schema envelope."""
        payload = {
            "schema_version": SCHEMA_VERSION,
            "updated_at": datetime.now().isoformat(timespec="seconds"),
            "total_records": len(contacts),
            "contacts": [contact.to_dict() for contact in contacts],
        }
        temp_path = path.with_suffix(".json.tmp")
        temp_path.write_text(
            json.dumps(payload, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )
        temp_path.replace(path)

    def _write_csv(self, path: Path, contacts: list[EmergencyContact]) -> None:
        """Write contacts atomically to CSV using canonical column order."""
        temp_path = path.with_suffix(".csv.tmp")
        with temp_path.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(CSV_COLUMNS))
            writer.writeheader()
            for contact in contacts:
                row = contact.to_dict()
                row["full_name"] = sanitize_csv_cell(row["full_name"])
                row["organization"] = sanitize_csv_cell(row["organization"])
                row["location_zone"] = sanitize_csv_cell(row["location_zone"])
                row["notes"] = sanitize_csv_cell(row["notes"])
                writer.writerow(row)
        temp_path.replace(path)
