"""Emergency Contact Organizer (Project #71 - CampusSolve).

A robust, zero-dependency Python 3.10+ application for storing, validating,
searching, auditing, and summarizing trusted local emergency contacts.
"""

__version__ = "1.0.0"
__app_name__ = "Emergency Contact Organizer"
__project_id__ = "Project #71: CampusSolve"
