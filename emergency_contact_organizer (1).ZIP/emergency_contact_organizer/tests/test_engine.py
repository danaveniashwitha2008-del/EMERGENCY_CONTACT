"""Tests for core engine CRUD, search, analytics, alerts, and bulk CSV import."""

from datetime import date, timedelta
from pathlib import Path
import tempfile
import unittest

from emergency_organizer.engine import EmergencyContactEngine
from emergency_organizer.storage import ContactStorage


class TestEngine(unittest.TestCase):
    def _make_engine(self, tmp: str) -> EmergencyContactEngine:
        storage = ContactStorage(
            data_dir=Path(tmp) / "data", logs_dir=Path(tmp) / "logs"
        )
        return EmergencyContactEngine(storage=storage)

    def test_crud_search_and_persistence_across_restart(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            engine = self._make_engine(tmp)
            c1 = engine.add_contact(
                {
                    "full_name": "Campus Health ER",
                    "organization": "University Hospital",
                    "category": "Medical",
                    "phone": "+1-555-222-1000",
                    "priority_level": 1,
                    "response_time_mins": 5.0,
                    "availability": "24/7",
                    "location_zone": "Central Quad",
                }
            )
            self.assertEqual(c1.contact_id, "ECO-001")

            # Reload in a brand-new engine instance to prove persistence
            engine2 = self._make_engine(tmp)
            self.assertEqual(len(engine2.contacts), 1)
            hits = engine2.search_contacts(keyword="hospital", category="Medical")
            self.assertEqual(len(hits), 1)
            self.assertEqual(hits[0].contact_id, "ECO-001")

            digit_hits = engine2.search_contacts(keyword="5552221000")
            self.assertEqual(len(digit_hits), 1)

            updated = engine2.update_contact("ECO-001", {"response_time_mins": 4.0})
            self.assertEqual(updated.response_time_mins, 4.0)

            deleted = engine2.delete_contact("ECO-001")
            self.assertEqual(deleted.contact_id, "ECO-001")
            self.assertEqual(len(engine2.contacts), 0)

    def test_threshold_alerts_and_summary(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            engine = self._make_engine(tmp)
            old_date = (date.today() - timedelta(days=250)).isoformat()
            engine.add_contact(
                {
                    "full_name": "Slow Critical Unit",
                    "organization": "Safety Office",
                    "category": "Campus Security",
                    "phone": "+1-555-900-1111",
                    "priority_level": 1,
                    "response_time_mins": 25.0,  # exceeds 8m SLA
                    "availability": "On-Call",  # non-24/7 P1 warning
                    "location_zone": "West Wing",
                    "last_verified_date": old_date,
                    "verification_interval_days": 90,
                }
            )
            alerts = engine.evaluate_threshold_alerts()
            codes = {a.code for a in alerts}
            self.assertIn("OVERDUE_VERIFICATION", codes)
            self.assertIn("SLA_RESPONSE_BREACH", codes)
            self.assertIn("CRITICAL_LIMITED_HOURS", codes)
            self.assertIn("MISSING_BACKUP_PHONE", codes)

            summary = engine.generate_summary()
            self.assertEqual(summary.total_contacts, 1)
            self.assertEqual(summary.overdue_verification_count, 1)
            self.assertEqual(summary.avg_response_time_mins, 25.0)

    def test_bulk_csv_import_with_row_error_log(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            engine = self._make_engine(tmp)
            csv_file = Path(tmp) / "legacy.csv"
            csv_file.write_text(
                "\n".join(
                    [
                        "id,name,org,cat,tel,priority,eta_mins,availability,zone,last_verified,review_days,trusted,status",
                        "ECO-010,Alpha Rescue,Fire Dept,Fire & Rescue,911,1,4.0,24/7,North,2026-10-01,90,yes,Active",
                        "ECO-011,Bad Row,Org,BadCat,12,9,9999,Never,X,2099-01-01,0,maybe,BadStatus",
                        "ECO-010,Duplicate ID,Fire Dept,Fire & Rescue,911,1,4.0,24/7,North,2026-10-01,90,yes,Active",
                    ]
                ),
                encoding="utf-8",
            )
            result = engine.import_csv(csv_file, on_duplicate="skip")
            self.assertEqual(result.total_rows, 3)
            self.assertEqual(result.imported_count, 1)
            self.assertEqual(result.skipped_duplicate_count, 1)
            self.assertEqual(result.failed_count, 1)
            self.assertTrue(Path(result.error_log_path).exists())


if __name__ == "__main__":
    unittest.main()
