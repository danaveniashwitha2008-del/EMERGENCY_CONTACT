"""End-to-end user journey test matching Section 9 ('What a Good Demo Looks Like')."""

from datetime import date
from pathlib import Path
import tempfile
import unittest

from emergency_organizer.cli import EmergencyCLI
from emergency_organizer.engine import EmergencyContactEngine
from emergency_organizer.exporter import SummaryExporter
from emergency_organizer.storage import ContactStorage


class TestCLIEndToEnd(unittest.TestCase):
    def test_demo_journey_validation_analytics_persistence_export(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            data_dir = Path(tmp) / "data"
            logs_dir = Path(tmp) / "logs"
            exports_dir = Path(tmp) / "exports"

            storage1 = ContactStorage(data_dir=data_dir, logs_dir=logs_dir)
            engine1 = EmergencyContactEngine(storage=storage1)
            exporter1 = SummaryExporter(exports_dir=exports_dir, storage=storage1)

            today = date.today().isoformat()
            # Simulate interactive inputs:
            # 4 -> Add contact (with intentional invalid name, phone, priority to test recovery)
            # 7 -> Executive Summary & Analytics
            # 10 -> Export all formats (option 1)
            # 0 -> Exit
            scripted_inputs = iter(
                [
                    "4",
                    "X",                    # invalid name (< 2 chars)
                    "Campus Rescue Squad",  # valid name
                    "Campus Safety",        # org
                    "2",                    # category: Fire & Rescue
                    "12",                   # invalid phone (< 3 digits)
                    "+1-555-301-9911",      # valid phone
                    "",                     # alternate phone (skip)
                    "bad-email",            # invalid email
                    "rescue@campus.edu",    # valid email
                    "9",                    # invalid priority (> 5)
                    "1",                    # valid priority
                    "5.5",                  # response time
                    "1",                    # availability: 24/7
                    "North Campus",         # location zone
                    today,                  # last verified
                    "90",                   # verification interval
                    "y",                    # trusted
                    "1",                    # status: Active
                    "Rapid response team",  # notes
                    "7",                    # Executive Summary
                    "10",                   # Export
                    "1",                    # All formats
                    "0",                    # Exit
                ]
            )
            outputs: list[str] = []
            cli1 = EmergencyCLI(
                engine1,
                exporter1,
                use_color=False,
                input_fn=lambda _: next(scripted_inputs),
                output_fn=outputs.append,
            )
            cli1.run()

            joined_out = "\n".join(outputs)
            self.assertIn("Invalid input", joined_out)
            self.assertIn("Added ECO-001", joined_out)
            self.assertIn("EXECUTIVE SUMMARY & OPERATIONAL ANALYTICS", joined_out)
            self.assertIn("Exported All Reports", joined_out)

            # Re-launch with a fresh engine instance to prove state persistence
            storage2 = ContactStorage(data_dir=data_dir, logs_dir=logs_dir)
            engine2 = EmergencyContactEngine(storage=storage2)
            self.assertEqual(len(engine2.contacts), 1)
            self.assertEqual(engine2.contacts[0].full_name, "Campus Rescue Squad")
            self.assertTrue(list(exports_dir.glob("*.md")))
            self.assertTrue(list(exports_dir.glob("*.txt")))
            self.assertTrue(list(exports_dir.glob("*.csv")))
            self.assertTrue(list(exports_dir.glob("*.html")))


if __name__ == "__main__":
    unittest.main()
