# Emergency Contact Organizer — Executive Summary Report

- **Generated:** 2026-11-25 11:14:23
- **Total Contacts:** 42
- **Active / Standby / Overdue / Inactive:** 35 / 3 / 3 / 1
- **Trusted Contacts:** 40
- **24/7 Coverage:** 29
- **Average Response Time:** 48.49 mins (Median: 12.00 mins, Range: 0.0–1440.0 mins)
- **Average Readiness Score:** 91.8 / 100
- **Overdue Verifications:** 4

## Category Distribution & Avg Response Time

| Category | Contacts | Avg Response (mins) |
|---|---:|---:|
| Campus Security | 6 | 7.92 |
| Medical | 5 | 15.60 |
| Utility & Infrastructure | 5 | 20.00 |
| Community Shelter | 4 | 25.75 |
| Family & Personal | 4 | 383.25 |
| Mental Health & Crisis | 4 | 1.50 |
| Poison & Hazmat | 4 | 7.88 |
| Roadside & Transport | 4 | 20.25 |
| Fire & Rescue | 3 | 10.33 |
| Law Enforcement | 3 | 8.50 |

## Priority Breakdown

| Priority | Label | Count |
|---:|---|---:|
| P1 | Critical | 13 |
| P2 | High | 16 |
| P3 | Medium | 8 |
| P4 | Standard | 4 |
| P5 | Low | 1 |

## Threshold Warnings & Anomalies

| Severity | Code | Contact | Details |
|---|---|---|---|
| CRITICAL | `OVERDUE_VERIFICATION` | ECO-009 (Hazmat & Chemical Spill Team) | Verification overdue by 9 day(s) (last verified 2026-08-18, interval 90d). |
| CRITICAL | `OVERDUE_VERIFICATION` | ECO-018 (Biohazard Waste Response Unit) | Verification overdue by 75 day(s) (last verified 2026-03-15, interval 180d). |
| CRITICAL | `OVERDUE_VERIFICATION` | ECO-035 (Wildfire & Smoke Air Advisory) | Verification overdue by 58 day(s) (last verified 2026-04-01, interval 180d). |
| CRITICAL | `OVERDUE_VERIFICATION` | ECO-037 (Legacy Annex Guard Post) | Verification overdue by 650 day(s) (last verified 2024-11-15, interval 90d). |
| WARNING | `DUPLICATE_PHONE` | ECO-002 (Campus Police Emergency Desk) | Shares normalized phone '5552019111' with [ECO-002, ECO-039]. |
| WARNING | `CRITICAL_LIMITED_HOURS` | ECO-009 (Hazmat & Chemical Spill Team) | Priority 1 (Critical) contact only available 'On-Call', not 24/7. |
| WARNING | `SLA_RESPONSE_BREACH` | ECO-018 (Biohazard Waste Response Unit) | Response time 14.0 min exceeds Poison & Hazmat SLA limit (10 min). |
| WARNING | `SLA_RESPONSE_BREACH` | ECO-020 (Dean on Call (Student Crisis)) | Response time 15.0 min exceeds Campus Security SLA limit (8 min). |
| WARNING | `SLA_RESPONSE_BREACH` | ECO-021 (Dr. Maya Nair (Primary Physician)) | Response time 30.0 min exceeds Family & Personal SLA limit (20 min). |
| WARNING | `SLA_RESPONSE_BREACH` | ECO-023 (Priya Sharma (Next of Kin)) | Response time 45.0 min exceeds Family & Personal SLA limit (20 min). |
| WARNING | `SLA_RESPONSE_BREACH` | ECO-030 (West Valley Dental Emergency) | Response time 45.0 min exceeds Medical SLA limit (12 min). |
| WARNING | `SLA_RESPONSE_BREACH` | ECO-035 (Wildfire & Smoke Air Advisory) | Response time 20.0 min exceeds Fire & Rescue SLA limit (10 min). |
| WARNING | `SLA_RESPONSE_BREACH` | ECO-036 (A2) | Response time 1440.0 min exceeds Family & Personal SLA limit (20 min). |
| WARNING | `INACTIVE_TRUSTED` | ECO-037 (Legacy Annex Guard Post) | Contact is marked Trusted but status is Inactive. |
| WARNING | `DUPLICATE_PHONE` | ECO-039 (Campus Escort Desk Mirror) | Shares normalized phone '5552019111' with [ECO-002, ECO-039]. |
| INFO | `MISSING_BACKUP_PHONE` | ECO-006 (Poison Control National Center) | Priority 1 contact has no alternate/backup phone number. |

## Critical & High-Priority Directory Snapshot

| ID | Name | Category | Phone | Availability | ETA (m) | Readiness | Status |
|---|---|---|---|---|---:|---:|---|
| ECO-005 | 988 Suicide & Crisis Lifeline | Mental Health & Crisis | 988 | 24/7 | 0.0 | 100.0 | Active |
| ECO-006 | Poison Control National Center | Poison & Hazmat | +1-800-222-1222 | 24/7 | 0.5 | 95.0 | Active |
| ECO-011 | Campus Counseling Crisis Line | Mental Health & Crisis | +1-555-203-2277 | 24/7 | 2.0 | 100.0 | Active |
| ECO-002 | Campus Police Emergency Desk | Campus Security | (555) 201-9111 | 24/7 | 2.5 | 100.0 | Active |
| ECO-001 | National Emergency Dispatch | Law Enforcement | 911 | 24/7 | 3.0 | 100.0 | Active |
| ECO-027 | Sexual Assault Response Advocate | Mental Health & Crisis | +1-555-203-7273 | 24/7 | 3.0 | 100.0 | Active |
| ECO-003 | University Fire & Rescue Unit | Fire & Rescue | +1-555-201-3473 | 24/7 | 4.5 | 100.0 | Active |
| ECO-010 | Metro Fire Station #4 | Fire & Rescue | +1-555-322-7700 | 24/7 | 6.5 | 100.0 | Active |
| ECO-019 | Regional Ambulance EMS Base | Medical | +1-555-315-9900 | 24/7 | 7.0 | 100.0 | Active |
| ECO-041 | Radiological Safety Officer | Poison & Hazmat | +1-555-204-9100 | 24/7 | 7.5 | 100.0 | Active |
| ECO-004 | Mercy General Trauma Center ER | Medical | +1-555-310-4000 | 24/7 | 8.0 | 100.0 | Active |
| ECO-009 | Hazmat & Chemical Spill Team | Poison & Hazmat | +1-555-204-8800 | On-Call | 9.5 | 75.1 | Overdue Review |
| ECO-012 | Gas Leak Emergency Hotline | Utility & Infrastructure | +1-800-555-0199 | 24/7 | 15.0 | 100.0 | Active |
| ECO-008 | North Quad Security Booth | Campus Security | +1-555-201-5501 | 24/7 | 4.0 | 100.0 | Active |
| ECO-029 | South Dorms Resident Director | Campus Security | +1-555-208-7700 | On-Call | 5.0 | 96.0 | Active |
