"""Defensive input validation, sanitization, and safe terminal input wrappers."""

from __future__ import annotations

from datetime import date
import math
import re
from typing import Any, Callable, Sequence, TypeVar

from .models import (
    MAX_PRIORITY,
    MAX_RESPONSE_MINS,
    MAX_VERIFICATION_INTERVAL,
    MIN_PRIORITY,
    MIN_RESPONSE_MINS,
    MIN_VERIFICATION_INTERVAL,
    VALID_AVAILABILITIES,
    VALID_CATEGORIES,
    VALID_STATUSES,
    EmergencyContact,
    normalize_phone_digits,
)

T = TypeVar("T")

CONTACT_ID_PATTERN = re.compile(r"^ECO-\d{3,6}$")
NAME_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9 .,'&()/+#\-]{1,79}$")
PHONE_FORMAT_PATTERN = re.compile(r"^[0-9+\-().\s]{3,24}$")
EMAIL_PATTERN = re.compile(
    r"^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,24}$"
)
CONTROL_CHARS_PATTERN = re.compile(r"[\x00-\x1f\x7f]")


class ValidationError(ValueError):
    """Raised when one or more domain validation rules fail."""

    def __init__(self, errors: Sequence[str]) -> None:
        self.errors = list(errors)
        super().__init__("; ".join(self.errors))


def sanitize_text(value: Any, max_length: int = 120) -> str:
    """Strip control characters, collapse whitespace, and enforce max length."""
    if value is None:
        return ""
    cleaned = CONTROL_CHARS_PATTERN.sub(" ", str(value))
    cleaned = " ".join(cleaned.split()).strip()
    if len(cleaned) > max_length:
        cleaned = cleaned[:max_length].rstrip()
    return cleaned


def sanitize_csv_cell(value: str) -> str:
    """Guard against CSV formula injection when exporting untrusted text."""
    text = sanitize_text(value, max_length=300)
    if text and text[0] in ("=", "+", "-", "@") and not re.match(r"^\+\d", text):
        return f"'{text}"
    return text


def validate_contact_id(value: str) -> str:
    """Validate contact ID format (e.g., ECO-001)."""
    cid = sanitize_text(value, max_length=16).upper()
    if not CONTACT_ID_PATTERN.match(cid):
        raise ValueError("Contact ID must match format 'ECO-001' (3-6 digits).")
    return cid


def validate_full_name(value: str) -> str:
    """Validate and normalize contact or service display name."""
    name = sanitize_text(value, max_length=80)
    if len(name) < 2:
        raise ValueError("Full name must be at least 2 characters.")
    if not NAME_PATTERN.match(name):
        raise ValueError(
            "Full name contains unsupported characters (use letters, numbers, spaces, or .,'&()/#-)."
        )
    return name


def validate_organization(value: str) -> str:
    """Validate organization or department label."""
    org = sanitize_text(value, max_length=100)
    if not org:
        raise ValueError("Organization / Department cannot be blank.")
    if len(org) < 2:
        raise ValueError("Organization / Department must be at least 2 characters.")
    return org


def validate_category(value: str) -> str:
    """Validate category against supported domain categories (case-insensitive)."""
    cleaned = sanitize_text(value, max_length=40)
    lookup = {item.lower(): item for item in VALID_CATEGORIES}
    matched = lookup.get(cleaned.lower())
    if not matched:
        raise ValueError(
            f"Invalid category {value!r}. Expected one of: {', '.join(VALID_CATEGORIES)}."
        )
    return matched


def validate_phone(value: str, *, required: bool = True) -> str:
    """Validate phone number or emergency short-code (3 to 15 digits)."""
    raw = sanitize_text(value, max_length=24)
    if not raw:
        if required:
            raise ValueError("Primary phone number cannot be blank.")
        return ""
    if not PHONE_FORMAT_PATTERN.match(raw):
        raise ValueError(
            "Phone number may only contain digits, spaces, '+', '-', '(', ')', and '.'."
        )
    digits = normalize_phone_digits(raw)
    if not (3 <= len(digits) <= 15):
        raise ValueError(
            "Phone number must contain between 3 digits (short code) and 15 digits."
        )
    return raw


def validate_email(value: str) -> str:
    """Validate optional email address."""
    email = sanitize_text(value, max_length=100).lower()
    if not email or email in {"n/a", "none", "-"}:
        return ""
    if not EMAIL_PATTERN.match(email):
        raise ValueError(f"Invalid email format: {value!r}.")
    return email


def validate_priority(value: Any) -> int:
    """Validate integer priority level between 1 (Critical) and 5 (Low)."""
    if isinstance(value, bool):
        raise ValueError("Priority must be an integer between 1 and 5.")
    try:
        num = int(str(value).strip())
    except (TypeError, ValueError) as exc:
        raise ValueError("Priority must be a whole number between 1 and 5.") from exc
    if not (MIN_PRIORITY <= num <= MAX_PRIORITY):
        raise ValueError(
            f"Priority must be between {MIN_PRIORITY} (Critical) and {MAX_PRIORITY} (Low)."
        )
    return num


def validate_response_time(value: Any) -> float:
    """Validate estimated response time in minutes (0 to 1440)."""
    if isinstance(value, bool):
        raise ValueError("Response time must be a number in minutes.")
    try:
        mins = float(str(value).strip())
    except (TypeError, ValueError) as exc:
        raise ValueError("Response time must be a numeric value in minutes.") from exc
    if math.isnan(mins) or math.isinf(mins):
        raise ValueError("Response time must be a finite number.")
    if not (MIN_RESPONSE_MINS <= mins <= MAX_RESPONSE_MINS):
        raise ValueError(
            f"Response time must be between {MIN_RESPONSE_MINS:.0f} and {MAX_RESPONSE_MINS:.0f} minutes."
        )
    return round(mins, 1)


def validate_availability(value: str) -> str:
    """Validate availability schedule label."""
    cleaned = sanitize_text(value, max_length=32)
    lookup = {item.lower(): item for item in VALID_AVAILABILITIES}
    matched = lookup.get(cleaned.lower())
    if not matched:
        raise ValueError(
            f"Invalid availability {value!r}. Expected one of: {', '.join(VALID_AVAILABILITIES)}."
        )
    return matched


def validate_location_zone(value: str) -> str:
    """Validate campus or community zone description."""
    zone = sanitize_text(value, max_length=80)
    if len(zone) < 2:
        raise ValueError("Location / Zone must be at least 2 characters.")
    return zone


def validate_date_iso(value: str, *, allow_future: bool = False) -> str:
    """Validate YYYY-MM-DD date string."""
    text = sanitize_text(value, max_length=20)
    if not re.match(r"^\d{4}-\d{2}-\d{2}$", text):
        raise ValueError("Date must use YYYY-MM-DD format (e.g., 2026-11-25).")
    try:
        parsed = date.fromisoformat(text)
    except ValueError as exc:
        raise ValueError(f"Invalid calendar date: {text!r}.") from exc
    if not allow_future and parsed > date.today():
        raise ValueError("Last verified date cannot be in the future.")
    return parsed.isoformat()


def validate_verification_interval(value: Any) -> int:
    """Validate verification interval in days (1 to 730)."""
    if isinstance(value, bool):
        raise ValueError("Verification interval must be an integer in days.")
    try:
        days = int(str(value).strip())
    except (TypeError, ValueError) as exc:
        raise ValueError("Verification interval must be a whole number of days.") from exc
    if not (MIN_VERIFICATION_INTERVAL <= days <= MAX_VERIFICATION_INTERVAL):
        raise ValueError(
            f"Verification interval must be between {MIN_VERIFICATION_INTERVAL} and {MAX_VERIFICATION_INTERVAL} days."
        )
    return days


def validate_status(value: str) -> str:
    """Validate operational status."""
    cleaned = sanitize_text(value, max_length=32)
    lookup = {item.lower(): item for item in VALID_STATUSES}
    matched = lookup.get(cleaned.lower())
    if not matched:
        raise ValueError(
            f"Invalid status {value!r}. Expected one of: {', '.join(VALID_STATUSES)}."
        )
    return matched


def validate_bool_flag(value: Any) -> bool:
    """Validate boolean field from bool, int, or yes/no/true/false strings."""
    if isinstance(value, bool):
        return value
    if isinstance(value, int) and value in (0, 1):
        return bool(value)
    text = sanitize_text(value, max_length=16).lower()
    if text in {"true", "1", "yes", "y"}:
        return True
    if text in {"false", "0", "no", "n"}:
        return False
    raise ValueError(f"Invalid boolean flag {value!r} (expected yes/no or true/false).")


def validate_notes(value: Any) -> str:
    """Sanitize optional notes field."""
    return sanitize_text(value, max_length=250)


def validate_contact_payload(
    raw: dict[str, Any],
    *,
    require_id: bool = True,
    allow_future_date: bool = False,
) -> EmergencyContact:
    """Validate a raw contact dictionary and return a clean EmergencyContact.

    Collects all field-level errors before raising ValidationError so users and
    bulk CSV imports receive complete diagnostics in a single pass.
    """
    errors: list[str] = []
    cleaned: dict[str, Any] = {}

    if require_id or sanitize_text(raw.get("contact_id", "")):
        try:
            cleaned["contact_id"] = validate_contact_id(str(raw.get("contact_id", "")))
        except ValueError as exc:
            errors.append(str(exc))
    else:
        cleaned["contact_id"] = ""

    field_validators: list[tuple[str, Callable[[Any], Any]]] = [
        ("full_name", validate_full_name),
        ("organization", validate_organization),
        ("category", validate_category),
        ("phone", lambda v: validate_phone(str(v), required=True)),
        ("alternate_phone", lambda v: validate_phone(str(v), required=False)),
        ("email", validate_email),
        ("priority_level", validate_priority),
        ("response_time_mins", validate_response_time),
        ("availability", validate_availability),
        ("location_zone", validate_location_zone),
        (
            "last_verified_date",
            lambda v: validate_date_iso(str(v), allow_future=allow_future_date),
        ),
        ("verification_interval_days", validate_verification_interval),
        ("is_trusted", validate_bool_flag),
        ("status", validate_status),
        ("notes", validate_notes),
    ]

    defaults: dict[str, Any] = {
        "alternate_phone": "",
        "email": "",
        "priority_level": 2,
        "response_time_mins": 10.0,
        "availability": "24/7",
        "location_zone": "Campus-Wide",
        "last_verified_date": date.today().isoformat(),
        "verification_interval_days": 180,
        "is_trusted": True,
        "status": "Active",
        "notes": "",
    }

    for field_name, validator in field_validators:
        value = raw.get(field_name)
        if value is None or (isinstance(value, str) and not value.strip()):
            if field_name in defaults:
                value = defaults[field_name]
            else:
                value = ""
        try:
            cleaned[field_name] = validator(value)
        except ValueError as exc:
            errors.append(f"{field_name}: {exc}")

    if (
        cleaned.get("phone")
        and cleaned.get("alternate_phone")
        and normalize_phone_digits(cleaned["phone"])
        == normalize_phone_digits(cleaned["alternate_phone"])
    ):
        errors.append(
            "alternate_phone: Alternate phone must differ from primary phone."
        )

    if errors:
        raise ValidationError(errors)

    if raw.get("created_at"):
        cleaned["created_at"] = sanitize_text(raw["created_at"], max_length=32)
    if raw.get("updated_at"):
        cleaned["updated_at"] = sanitize_text(raw["updated_at"], max_length=32)

    return EmergencyContact.from_dict(cleaned)


# ---------------------------------------------------------------------------
# Centralized Terminal Input Wrappers
# ---------------------------------------------------------------------------


class InputCancelled(Exception):
    """Raised when a user enters 'cancel' or triggers EOF during a prompt."""


def prompt_validated(
    label: str,
    validator: Callable[[str], T],
    *,
    default: str | None = None,
    allow_cancel: bool = True,
    input_fn: Callable[[str], str] = input,
    output_fn: Callable[[str], None] = print,
) -> T:
    """Loop until input passes `validator` or the user cancels."""
    suffix = f" [{default}]" if default is not None and default != "" else ""
    cancel_hint = " (type 'cancel' to abort)" if allow_cancel else ""
    prompt_str = f"{label}{suffix}{cancel_hint}: "

    while True:
        try:
            raw = input_fn(prompt_str)
        except (EOFError, KeyboardInterrupt) as exc:
            raise InputCancelled("Input cancelled by user.") from exc

        stripped = raw.strip()
        if allow_cancel and stripped.lower() in {"cancel", "q!"}:
            raise InputCancelled("Operation cancelled by user.")
        if not stripped and default is not None:
            stripped = default

        try:
            return validator(stripped)
        except ValueError as exc:
            output_fn(f"  [!] Invalid input: {exc}")


def prompt_choice(
    label: str,
    options: Sequence[str],
    *,
    default: str | None = None,
    allow_cancel: bool = True,
    input_fn: Callable[[str], str] = input,
    output_fn: Callable[[str], None] = print,
) -> str:
    """Display numbered choices and accept either index number or exact name."""
    output_fn(f"\n{label}:")
    for idx, opt in enumerate(options, start=1):
        marker = " (default)" if default and opt == default else ""
        output_fn(f"  {idx}. {opt}{marker}")

    def _parse_choice(raw: str) -> str:
        if not raw and default is not None:
            return default
        if raw.isdigit():
            idx = int(raw)
            if 1 <= idx <= len(options):
                return options[idx - 1]
            raise ValueError(f"Enter a number between 1 and {len(options)}.")
        lookup = {item.lower(): item for item in options}
        matched = lookup.get(raw.lower())
        if matched:
            return matched
        raise ValueError(
            f"Choose a number (1-{len(options)}) or valid option name."
        )

    return prompt_validated(
        "Select option",
        _parse_choice,
        default=default,
        allow_cancel=allow_cancel,
        input_fn=input_fn,
        output_fn=output_fn,
    )


def prompt_yes_no(
    label: str,
    *,
    default: bool = True,
    allow_cancel: bool = True,
    input_fn: Callable[[str], str] = input,
    output_fn: Callable[[str], None] = print,
) -> bool:
    """Prompt cleanly for a yes/no confirmation."""
    default_str = "y" if default else "n"
    return prompt_validated(
        f"{label} (y/n)",
        validate_bool_flag,
        default=default_str,
        allow_cancel=allow_cancel,
        input_fn=input_fn,
        output_fn=output_fn,
    )
